<template>
  <div class='container'>预览文章对话框</div>
</template>

<script>
export default {}
</script>

<style scoped lang='less'></style>
