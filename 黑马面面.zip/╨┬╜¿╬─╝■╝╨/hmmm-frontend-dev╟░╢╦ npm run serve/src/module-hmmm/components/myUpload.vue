<template>
  <div class='container'>
    <el-upload
      :on-change="handleAvatar"
      :before-upload="beforeAvatarUpload"
      class="avatar-uploader"
      action=""
      :show-file-list="false">
      <el-image
        v-if="imgURL"
        :src="imgURL"
        class="avatar"
        style="width: 100px; height: 60px"
        fit="contain">
      </el-image>
      <span v-else>上传图片</span>
    </el-upload>
  </div>
</template>

<script>
export default {
  data () {
    return {
      imgURL: ''
    }
  },
  methods: {
    handleAvatar (file, fileList) {
      this.imgURL = URL.createObjectURL(file.raw)
    },
    beforeAvatarUpload (file) {
      const isJPG = file.type === 'image/jpeg'
      const isLt2M = file.size / 1024 / 1024 < 2

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!')
        this.imgURL = ''
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!')
      }
      return isJPG && isLt2M
    }
  }
}
</script>

<style scoped lang='css'>
  .avatar-uploader /deep/ .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    left: 5px;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader {
    font-size: 14px;
    color: #000;
    width: 100px;
    height: 60px;
    line-height: 60px;
    text-align: center;
  }
  .avatar {
    width: 100px;
    height: 60px;
    display: block;
  }
  .avatar-uploader /deep/ .el-upload{
    width: 100px;
  }
  .btnAdd{
    position: relative;
  }</style>
