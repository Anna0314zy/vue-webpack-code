<template>
  <div class='container'>添加标签对话框</div>
</template>

<script>
export default {}
</script>

<style scoped lang='less'></style>
