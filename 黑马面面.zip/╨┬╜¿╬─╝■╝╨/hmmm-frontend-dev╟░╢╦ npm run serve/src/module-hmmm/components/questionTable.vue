<template>
  <div class="qs_table">
    <el-table :data="questionList" style="width: 100%" v-loading="isLoading">
      <el-table-column label="序号" width="50">
        <template slot-scope="scope">
          {{(page - 1) * pagesize + (scope.$index + 1)}}
        </template>
      </el-table-column>
      <el-table-column prop="number" label="试题编号" width="120"></el-table-column>
      <el-table-column prop="subject" label="学科" width="120"> </el-table-column>
      <el-table-column prop="catalog" label="目录" width="120"> </el-table-column>
      <el-table-column label="题型" width="120">
        <template slot-scope="scope">
          <span v-if="scope.row.questionType == 1">单选</span>
          <span v-else-if="scope.row.questionType == 2">多选</span>
          <span v-else-if="scope.row.questionType == 3">简答</span>
        </template>
      </el-table-column>
      <el-table-column prop="question" label="题干" width="300">
      </el-table-column>
      <el-table-column label="录入时间" width="150">
        <template slot-scope="scope">
          {{ scope.row.addDate | formatData }}
        </template>
      </el-table-column>
      <el-table-column label="难度" width="120">
        <template slot-scope="scope">
          <span v-if="scope.row.difficulty == 1">简单</span>
          <span v-else-if="scope.row.difficulty == 2">一般</span>
          <span v-else-if="scope.row.difficulty == 3">困难</span>
        </template>
      </el-table-column>
      <el-table-column prop="creator" label="录入人" width="120">
      </el-table-column>
      <el-table-column label="审核状态" width="120">
        <template slot-scope="scope">
          <span v-if="scope.row.chkState == 0">待审核</span>
          <span v-else-if="scope.row.chkState == 1">审核通过</span>
          <span v-else-if="scope.row.chkState == 2">拒绝审核</span>
        </template>
      </el-table-column>
      <el-table-column prop="chkRemarks" label="审核意见" width="120">
      </el-table-column>
      <el-table-column prop="chkUser" label="审核人" width="120">
      </el-table-column>
      <el-table-column label="发布状态" width="120">
        <template slot-scope="scope">
          <span v-if="scope.row.publishState == 0">待发布</span>
          <span v-else-if="scope.row.publishState == 1">已发布</span>
        </template>
      </el-table-column>
      <el-table-column align="center" fixed="right" label="操作" width="200">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="previewDetails(scope.row.id)">预览</el-button>
          <el-button type="text" size="small" @click="toExamine(scope.row.id)" :disabled="scope.row.chkState !== 0 ? true : false">审核</el-button>
          <el-button type="text" size="small" @click="$router.push(`/questions/new?id=${scope.row.id}`)" :disabled="scope.row.chkState !== 2 ? true : false">修改</el-button>
          <el-button type="text" size="small" @click="hTheShelf(scope.row.id, scope.row.publishState)">{{scope.row.publishState === 0 ? '上架' : '下架'}}</el-button>
          <el-button type="text" size="small" @click="hDelQuestions(scope.row.id)" :disabled="scope.row.publishState !== 0 ? true : false">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 预览弹出框 -->
    <el-dialog
      title="题目预览"
      :visible.sync="dialogVisible"
      width="900px"
      :destroy-on-close="true"
      class="dialog_list">
      <el-row>
        <el-col :span="6">【题型】：
          <span v-if="preview.questionType == 1">单选</span>
          <span v-else-if="preview.questionType == 2">多选</span>
          <span v-else-if="preview.questionType == 3">简答题</span>
        </el-col>
        <el-col :span="6">【编号】：{{preview.id}}</el-col>
        <el-col :span="6">【难度】：{{preview.difficulty}}
          <span v-if="preview.difficulty == 1">简单</span>
          <span v-else-if="preview.difficulty == 2">一般</span>
          <span v-else-if="preview.difficulty == 3">困难</span>
        </el-col>
        <el-col :span="6">【标签】：{{preview.tags}}</el-col>
        <el-col :span="6">【学科】：{{preview.subjectName}}</el-col>
        <el-col :span="6">【目录】：{{preview.directoryName}}</el-col>
        <el-col :span="6">【方向】：{{preview.direction}}</el-col>
      </el-row>
      <hr>
      <!-- 简答 -->
      <el-row>
        <el-col :span="24">【题干】：</el-col>
        <div style="color: blue" v-html="preview.question">
        </div>
      </el-row>
      <!-- 单选 -->
      <el-row v-if="preview.questionType == 1">
        <el-col :span="24">单选题 选项：（以下选中的选项为正确答案）</el-col>
        <el-form>
          <el-form-item>
            <el-radio-group v-model="isRight" @change="radioChang">
              <div v-for="item in preview.options" :key="item.id" style="padding: 8px 0">
                <el-radio :label="item.isRight">{{item.title}}</el-radio>
              </div>
            </el-radio-group>
          </el-form-item>
        </el-form>
      </el-row>
      <!-- 多选 -->
      <el-row v-else-if="preview.questionType == 2">
        <el-col :span="24">多选题 选项：（以下选中的选项为正确答案）</el-col>
        <el-form>
          <el-form-item>
            <el-checkbox-group v-model="multipleChoice" @change="checkboxChang">
              <div v-for="item in preview.options" :key="item.id">
                <el-checkbox :label="item.title"></el-checkbox>
              </div>
            </el-checkbox-group>
          </el-form-item>
        </el-form>
      </el-row>
      <hr>
      <el-row>
        <el-col :span="24">
          【参考答案】：
          <el-button v-if="this.videoUrl !== ''" type="danger" size="small" @click="showVideoAnswer" style="backgrouond: black">视频答案预览</el-button>
        </el-col>
        <el-col :span="24" v-if="videoIsShow">
          <video :src="videoUrl" width="400px" controls="controls" autoplay></video>
        </el-col>
      </el-row>
      <hr>
      <el-row>
        <el-col :span="24">
          【答案解析】：
          <div v-html="preview.answer"></div>
        </el-col>
      </el-row>
      <hr>
      <el-row>
        <el-col :span="24">
          【题目备注】：{{preview.remarks}}
        </el-col>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">取 消</el-button>
      </span>
    </el-dialog>
    <!-- 审核弹出框 -->
    <el-dialog
      title="提示"
      :destroy-on-close="true"
      :visible.sync="ExamineDialogVisible"
      width="400px">
      <el-form ref="ExamineForm" :model="Examine" :rules="rules">
        <el-form-item label="">
          <el-radio-group v-model="Examine.chkState">
            <el-radio :label="1">通过</el-radio>
            <el-radio :label="2">拒绝</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="" prop="chkRemarks">
          <el-input type="textarea" v-model="Examine.chkRemarks" placeholder="请输入审核意见"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="hCancel">取 消</el-button>
        <el-button type="primary" @click="hExamine">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
// 导入日期格式化插件
import moment from 'moment'
// 引入接口方法
import { detail, choiceCheck, choicePublish, remove } from '@/api/hmmm/questions'
export default {
  props: ['questionList', 'page', 'pagesize', 'value'],
  data () {
    return {
      isLoading: false,
      dialogVisible: false, // 显示预览的弹出框
      ExamineDialogVisible: false, // 显示审核的弹出框
      videoIsShow: false, // 是否显示视频
      preview: {},
      videoUrl: '', // 视频地址
      isRight: 1, // 判断单选 1 是选中
      multipleChoice: [], // 用来存放多选的名称
      checkMultipleChoice: [], // 用来赋值回多选，不让用户进行修改
      Examine: {
        chkState: 1, // 审核状态
        chkRemarks: '' // 审核意见
      },
      examineId: null, // 当前点击审核的id
      rules: {
        chkRemarks: [
          { required: true, message: '请输入审核意见', trigger: 'blur' }
        ]
      }
    }
  },
  created () {
    this.isLoading = this.value
  },
  filters: {
    // 格式化日期
    formatData (date) {
      return moment(date).format('YYYY-MM-DD hh:mm:ss')
    }
  },
  methods: {
    // 查看详情
    previewDetails (id) {
      // 显示弹出框
      this.dialogVisible = true
      this.getPreviewData(id)
    },
    // 获取详情数据
    async getPreviewData (id) {
      const data = {
        id
      }
      // 请求接口，把请求过来的数据 赋值到data中
      const res = await detail(data)
      this.preview = res.data
      // 赋值视频链接
      this.videoUrl = res.data.videoURL
      // 判断当前有没有多选
      if (this.preview.questionType === '2') {
        // 处理多选的数据
        this.setMultipleChoice(this.preview.options)
      }
    },
    // 处理多选数据
    setMultipleChoice (obj) {
      // 通个循环找出 当前 选中的数值，存在一个数组中
      obj.forEach((item) => {
        if (item.isRight === 1) {
          this.multipleChoice.push(item.title)
          this.checkMultipleChoice.push(item.title)
        }
      })
    },
    // 点击视频答案预览 按钮 显示视频
    showVideoAnswer () {
      // 判断当前视频地址存在不
      if (this.videoUrl !== '') {
        this.videoIsShow = true
      }
    },
    // 切换单选时
    radioChang () {
      // 每次改变的时候，强制让单选的value变为1，让他不能改变
      this.isRight = 1
    },
    // 切换多选时
    checkboxChang () {
      this.multipleChoice = this.checkMultipleChoice
    },
    /* ************************************** */
    // 点击审核
    toExamine (id) {
      // 打开弹出框
      this.ExamineDialogVisible = true
      // 赋值当前的id
      this.examineId = id
    },
    // 审核点击确定
    hExamine () {
      // 点击确定再次验证表单
      this.$refs.ExamineForm.validate((valid) => {
        // 验证通过
        if (valid) {
          // 执行审核
          this.doExamine()
          this.$refs.ExamineForm.clearValidate()
        } else {
          return false
        }
      })
    },
    async doExamine () {
      this.Examine.id = this.examineId
      try {
        // 调用接口
        await choiceCheck(this.Examine)
        // 关闭弹出框
        this.ExamineDialogVisible = false
        // 重新渲染数据
        this.$emit('change-data')
        // 弹出提示信息
        this.$message.success('审核成功！')
        // 恢复默认审核值
        this.Examine.chkState = 1
        this.Examine.chkRemarks = ''
      } catch (error) {
        this.$message.error('审核出错！')
        console.log(error)
        // 恢复默认审核值
        this.Examine.chkState = 1
        this.Examine.chkRemarks = ''
      }
    },
    // 点击取消
    hCancel () {
      // 恢复默认审核值
      this.Examine.chkState = 1
      this.Examine.chkRemarks = ''
      // 关闭弹出框
      this.ExamineDialogVisible = false
      // 移除表单验证
      this.$refs.ExamineForm.clearValidate()
    },
    /* ************************** */
    // 点击上架或下架
    hTheShelf (id, publishState) {
      this.$confirm('您确认上架这道题目吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async () => {
        // 修改当前的上架状态值 如果是上架就改为下架 反之
        if (publishState === 1) {
          publishState = 0
        } else {
          publishState = 1
        }
        const data = {
          id,
          publishState
        }
        await choicePublish(data)

        // 重新渲染数据
        this.$emit('change-data')
        // 弹出提示信息
        if (publishState === 1) {
          this.$message.success('上架商品成功！')
        } else {
          this.$message.success('下架商品成功！')
        }
      }).catch(() => {})
    },
    /* *********************************** */
    // 删除试题
    hDelQuestions (id) {
      const data = { id }
      this.$confirm('此操作将永久删除该题目, 是否继续?', '删除提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async () => {
        try {
          // 调用接口
          await remove(data)
          // 重新渲染数据
          this.$emit('change-data')
          this.$message.success('删除成功！')
        } catch (error) {
          console.log(error)
          this.$message.error('删除失败！')
        }
      }).catch(() => {})
    }
  },
  watch: {
    value (newVal, oldVal) {
      this.isLoading = this.value
    },
    // 监听弹出框是否显示
    dialogVisible (newVal, oldVal) {
      // 如果弹出框关闭了
      if (!newVal) {
        // 把视频隐藏
        this.videoIsShow = false
        // 清空当前视频地址
        this.videoUrl = ''
      }
    }
  }
}
</script>

<style lang="css" scoped>
.qs_table /deep/ .el-dialog__footer {
  text-align: right;
}
.dialog_list /deep/ .el-col{
  padding: 10px 0;
}
</style>>
