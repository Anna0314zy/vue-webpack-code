<template>
  <div class='question-new-container'>
    <el-card class="box-card" style="margin-bottom: 10px">
      <div slot="header" class="clearfix">
        <span id="title">{{ this.$route.query.id? '试题修改' : '试题录入'}}</span>
      </div>
      <el-form :model="form" :rules="rules" ref="myForm" label-width="120px">
        <!-- 学科 -->
        <el-form-item label="学科:" prop="subjectID">
          <el-select @change="hChangeSubject" v-model="form.subjectID" placeholder="请选择" class="w400">
            <el-option v-for="subject in subjects" :label="subject.label" :value="subject.value" :key="subject.value"></el-option>
          </el-select>
        </el-form-item>
        <!-- 目录 -->
        <el-form-item label="目录:" prop="catalogID">
          <el-select v-model="form.catalogID" placeholder="请选择" class="w400">
            <el-option v-for="directory in directorys" :label="directory.label" :value="directory.value" :key="directory.value"></el-option>
          </el-select>
        </el-form-item>
        <!-- 企业 -->
        <el-form-item label="企业:" prop="enterpriseID">
          <el-select v-model="form.enterpriseID" placeholder="请选择" class="w400">
            <el-option v-for="company in companys" :label="company.company" :value="company.id" :key="company.id"></el-option>
          </el-select>
        </el-form-item>
        <!-- 城市 -->
        <el-form-item label="城市:" prop="city">
          <el-select
              @change="hCityData"
              v-model="form.province"
              placeholder="请选择"
              style="margin-right: 4px"
              class="w198"
              >
            <el-option
              v-for="province in citySelect.province"
              :label="province"
              :value="province"
              :key="province"
              >
            </el-option>
          </el-select>
          <el-select v-model="form.city" placeholder="请选择" class="w198">
            <el-option
              v-for="city in citySelect.cityData"
              :label="city"
              :value="city"
              :key="city"
              >
            </el-option>
          </el-select>
        </el-form-item>
        <!-- 方向 -->
        <el-form-item label="方向:" prop="direction">
          <el-select v-model="form.direction" placeholder="请选择" class="w400">
            <el-option v-for="direction in direction" :label="direction" :value="direction" :key="direction"></el-option>
          </el-select>
        </el-form-item>
        <!-- 题型 -->
        <el-form-item label="题型:" prop="questionType">
            <el-radio
              @change="hQuestionType"
              v-model="form.questionType"
              v-for="questionType in questionType"
              :label="questionType.value.toString()"
              :key="questionType.value">
              {{questionType.label}}
            </el-radio>
        </el-form-item>
        <!-- 难度 -->
        <el-form-item label="难度:" prop="difficulty">
          <el-radio
              v-model="form.difficulty"
              v-for="difficulty in difficulty"
              :label="difficulty.value.toString()"
              :key="difficulty.value">
              {{difficulty.label}}
            </el-radio>
        </el-form-item>
        <!-- 题干 -->
        <el-form-item label="题干:" prop="question">
          <quill-editor v-model="form.question" :options="editorOption"></quill-editor>
        </el-form-item>
        <!-- 选项 -->
        <!-- 单选组 -->
        <el-form-item
          :label="idx === 0 ? '选项：' : ''"
          :class="form.questionType == '1'? 'show': 'hide'"
          style="margin-bottom:10px"
          v-for="(option,idx) in radioOptions"
          :key="idx">
            <el-radio  v-model="isRight" :label="option.code" class="option">{{option.code}}：</el-radio>
            <el-input v-model="option.title" class="option-input"></el-input>
            <my-upload v-model="option.img" style="display:inline-block"></my-upload>
        </el-form-item>
        <!-- 多选组 -->
        <el-form-item
          :label="index === 0 ? '选项：' : ''"
          :class="form.questionType === '2'? 'show': 'hide'"
          style="margin-bottom:10px"
          v-for="(option,index) in checkOptions"
          :key="option.index">
            <el-checkbox v-model="option.isRight" :label="option.code" class="option">{{option.code}}：</el-checkbox>
            <el-input v-model="option.title" class="option-input"></el-input>
            <my-upload v-model="option.img" style="display:inline-block"></my-upload>
        </el-form-item>
        <el-form-item>
          <el-button :class="form.questionType === '3'? 'hide': 'show'" @click="hAddOption" class="btnAdd" type="danger" :disabled="isDisabled">+增加选项与答案</el-button>
        </el-form-item>
        <!-- 解析视频 -->
        <el-form-item label="解析视频:" :prop="$route.query.id ? 'videoURL' : ''">
          <el-input v-model="form.videoURL" class="w400"></el-input>
        </el-form-item>
        <!-- 答案解析 -->
        <el-form-item label="答案解析:" prop="answer">
          <!-- 使用富文本组件并配置 -->
          <quill-editor v-model="form.answer" :options="editorOption"></quill-editor>
        </el-form-item>
        <!-- 题目备注 -->
        <el-form-item label="题目备注:" :prop="$route.query.id ? 'remarks' : ''">
          <el-input
            v-model="form.remarks"
            class="w400"
            type="textarea"
            :rows="4"
            placeholder="">
          </el-input>
        </el-form-item>
        <!-- 试题标签 -->
        <el-form-item label="试题标签:" prop="tags">
          <!-- el-select设置multiple属性即可启用多选 -->
          <el-select v-model="selectTags" multiple  placeholder="请选择" class="w400">
            <el-option v-for="tag in tags" :label="tag.label" :value="tag.label" :key="tag.value"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button @click="hSubmit" type="primary">{{ this.$route.query.id? '试题修改' : '试题录入'}}</el-button>
          <!-- <el-button @click="resetForm" type="primary">清空</el-button> -->
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
// 富文本
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import { quillEditor } from 'vue-quill-editor'
// 图片组件
import MyUpload from '@/module-hmmm/components/myUpload.vue'
// 引入接口方法
import { simple as subList } from '@/api/hmmm/subjects'
import { simple as dirList } from '@/api/hmmm/directorys'
import { list as comList } from '@/api/hmmm/companys'
import { provinces, citys } from '@/api/hmmm/citys.js'
import { direction, questionType, difficulty } from '@/api/hmmm/constants.js'
import { simple as tagList } from '@/api/hmmm/tags.js'
import { add, detail, update } from '@/api/hmmm/questions.js'
export default {
  // 注册组件
  components: {
    quillEditor,
    MyUpload
  },
  data () {
    return {
      // 富文本配置对象
      editorOption: {
        // 占位配置
        placeholder: '',
        modules: {
        // 配置工具栏
          toolbar: [
            ['bold', 'italic', 'underline', 'strike'],
            [{ list: 'ordered' }, { list: 'bullet' }],
            ['blockquote', 'code-block'],
            ['image', 'link']
          ]
        }
      },
      // 表单校验规则
      rules: {
        // 规则名需要和绑定数据的名一致
        // 学科
        subjectID: [
          { required: true, message: '请选择学科', trigger: 'change' }
        ],
        // 目录
        catalogID: [
          { required: true, message: '请选择目录', trigger: 'change' }
        ],
        // 企业
        enterpriseID: [
          { required: true, message: '请选择企业', trigger: 'change' }
        ],
        // 城市
        city: [
          { required: true, message: '请选择城市', trigger: 'change' }
        ],
        // 方向
        direction: [
          { required: true, message: '请选择方向', trigger: 'change' }
        ],
        // 题型
        questionType: [
          { required: true, trigger: 'change' }
        ],
        // 难度
        difficulty: [
          { required: true, trigger: 'change' }
        ],
        // 题干
        question: [
          { required: true, message: '请输入题干', trigger: 'blur' }
        ],
        // 解析视频地址
        videoURL: [
          { required: true, message: '请输入解析视频', trigger: 'blur' },
          {
            pattern: /(http(s)?:\/\/)?\w+(\.\w+)+\/(\w+\/)*(.*?\.)+(avi|flv|wav|mp3|mp4)/,
            message: '格式不正确',
            trigger: 'blur'
          }
        ],
        // 题目备注
        remarks: [
          { required: true, message: '请输入题目备注', trigger: 'blur' }
        ],
        // 答案解析
        answer: [
          { required: true, message: '请输入答案解析', trigger: 'blur' }
        ]
      },
      subjects: [], // 学科列表
      directorys: [], // 目录列表
      companys: [], // 企业列表
      citySelect: { // 省市数据
        province: [], // 省会列表
        cityData: [] // 城市列表
      },
      direction, // 方向列表
      questionType, // 题型列表
      difficulty, // 难度列表
      tags: [], // 标签列表
      // 默认选项数据
      defaultOptions: [
        {
          code: 'A',
          title: '',
          img: '',
          isRight: false
        },
        {
          code: 'B',
          title: '',
          img: '',
          isRight: false
        },
        {
          code: 'C',
          title: '',
          img: '',
          isRight: false
        },
        {
          code: 'D',
          title: '',
          img: '',
          isRight: false
        }
      ],
      // 表单数据
      form: {
        subjectID: '', // 选中学科
        catalogID: '', // 选中目录
        enterpriseID: '', // 选中企业
        province: '',
        city: '',
        direction: '', // 方向
        questionType: '1',
        difficulty: '1',
        question: '', // 题干
        // 选项
        options: [],
        videoURL: '', // 解析视频
        answer: '', // 答案解析
        remarks: '', // 题目备注
        tags: '', // 试题标签
        isPerfect: false // 是否精选题
      },
      // 单选组默认数据
      radioOptions: [
        {
          code: 'A',
          title: '',
          img: '',
          isRight: false
        },
        {
          code: 'B',
          title: '',
          img: '',
          isRight: false
        },
        {
          code: 'C',
          title: '',
          img: '',
          isRight: false
        },
        {
          code: 'D',
          title: '',
          img: '',
          isRight: false
        }
      ],
      // 多选默认数据
      checkOptions: [
        {
          code: 'A',
          title: '',
          img: '',
          isRight: false
        },
        {
          code: 'B',
          title: '',
          img: '',
          isRight: false
        },
        {
          code: 'C',
          title: '',
          img: '',
          isRight: false
        },
        {
          code: 'D',
          title: '',
          img: '',
          isRight: false
        }
      ],
      selectTags: [], // 选中标签
      codeInt: 69, // 选项代码值
      isRight: '', // 单选框选中代码值
      checkArray: [], // 多选框选中代码值
      isDisabled: true // 添加选项按钮是否可用
    }
  },
  created () {
    if (this.$route.query.id) {
      // 获取试题详情
      this.loadQuestion({ id: this.$route.query.id })
    }
    this.getProvince() // 获取省会
    this.loadSubList() // 获取学科列表
    this.loadComList() // 获取企业列表
    // 初始化选项数据
    this.form.options = this.radioOptions
    // this.checkOptions = this.radioOptions
  },
  watch: {
    // 监听路由变化
    '$route.fullPath' (newVal, oldVal) {
      if (newVal.includes('id')) {
        // 渲染试题详情
        this.loadQuestion({ id: this.$route.query.id })
      } else {
        // this.$nextTick将回调延迟到下次 DOM 更新之后执行
        this.$nextTick(() => {
          // 移除表单项的校验结果
          this.$refs.myForm.clearValidate()
        })
        // 重置表单数据
        this.resetForm()
      }
    }
  },
  methods: {
    // 重置表单数据
    resetForm () {
      this.$refs.myForm.resetFields()
      this.citySelect.cityData = []
      this.form.province = ''
      this.form.city = ''
      this.form.options = []
      this.radioOptions = this.defaultOptions
      this.checkOptions = this.defaultOptions
      this.isRight = ''
      this.checkArray = []
      this.selectTags = []
      this.tags = []
      this.directorys = []
    },
    // 渲染试题详情
    async loadQuestion (id) {
      // 获取试题详情
      const { data: res } = await detail(id)
      // console.log(res)
      // 处理数据
      this.loadDirList({ subjectID: res.subjectID })
      this.loadTagList({ subjectID: res.subjectID })
      this.getProvince()
      this.loadCity(res.province)
      this.selectTags = res.tags.split(',')
      if (res.questionType === '1') {
        // 单选选中状态
        res.options.map(item => {
          if (item.isRight) {
            this.isRight = item.code
          }
        })
        this.radioOptions = res.options
      } else if (res.questionType === '2') {
        // 多选选中状态
        res.options.map(item => {
          item.isRight = Boolean(item.isRight)
        })
        this.checkOptions = res.options
      }
      // 渲染表单数据
      this.form = res
    },
    // 提交数据
    hSubmit () {
      // this.doSubmit()
      this.$refs.myForm.validate((valid) => {
        if (valid) {
          this.doSubmit()
        } else {
          this.$message.error('请填写完整内容')
          return false
        }
      })
    },
    async doSubmit () {
      if (this.form.questionType === '1') {
        // 处理单选数据
        this.radioOptions.map(item => {
          if (item.code.includes(this.isRight)) {
            item.isRight = true
          }
        })
        this.form.options = this.radioOptions
      } else if (this.form.questionType === '2') {
        // 多选数据
        this.form.options = this.checkOptions
      }
      // console.log(this.form.options)
      // 处理标签数据
      this.tagsToString()
      // 发请求
      if (this.$route.query.id) {
        // --试题修改
        try {
          const { data: res } = await update(this.form)
          console.log(res)
          this.$message.success('试题更新成功')
          // 跳转至基础题库
          this.$router.push('/questions/list')
        } catch (err) {
          console.log(err)
          this.$message.error('试题更新失败')
        }
      } else {
        // --试题录入
        try {
          const { data: res } = await add(this.form)
          console.log(res)
          this.$message.success('试题录入成功')
          // 跳转至基础题库
          this.$router.push('/questions/list')
        } catch (err) {
          this.$message.error('试题录入失败')
        }
      }
    },
    // 增加多选选项
    hAddOption () {
      const option = {
        code: String.fromCharCode(this.codeInt),
        title: '',
        img: '',
        isRight: false
      }
      this.checkOptions.push(option)
      this.codeInt++
    },
    // 处理标签数据
    tagsToString () {
      this.form.tags = this.selectTags.join(',')
    },
    // 题型选择
    hQuestionType (questionType) {
      // console.log(questionType)
      this.form.questionType = questionType
      // 单选
      if (this.form.questionType === '1') {
        this.form.options = this.radioOptions
        this.isDisabled = true
      } else if (this.form.questionType === '2') { // 多选
        this.form.options = this.checkOptions
        this.isDisabled = false
      } else if (this.form.questionType === '3') { // 简答
        this.form.options = []
      }
    },
    // 根据选择学科显示目录列表，标签列表
    hChangeSubject (subjectID) {
      // 清空目录列表，标签列表
      this.directorys = []
      this.tags = []
      this.selectTags = []
      // 清空表单数据
      this.form.catalogID = ''
      this.form.tags = ''
      // 目录列表
      this.loadDirList({ subjectID })
      // 标签列表
      this.loadTagList({ subjectID })
    },
    hUploadSuccess (res, file) {
      this.img = URL.createObjectURL(file.raw)
    },
    // 获取学科列表
    async loadSubList () {
      const { data: res } = await subList()
      // console.log(res)
      this.subjects = res
    },
    // 获取目录列表
    async loadDirList (params) {
      const { data: res } = await dirList(params)
      // console.log(res)
      this.directorys = res
    },
    // 获取企业列表
    async loadComList () {
      const { data: res } = await comList()
      // console.log(res.items)
      this.companys = res.items
    },
    // 获取标签列表
    async loadTagList (params) {
      const { data: res } = await tagList(params)
      // console.log(res)
      this.tags = res
    },
    // 获取省
    getProvince () {
      this.citySelect.province = provinces()
      // console.log(provinces())
    },
    // 根据省会获取城市列表
    hCityData (e) {
      this.citySelect.cityData = []
      this.form.city = ''
      this.citySelect.cityData = citys(e)
      // console.log(this.citySelect.cityData)
    },
    // 根据省会获取城市列表
    loadCity (province) {
      this.citySelect.cityData = []
      this.citySelect.cityData = citys(province)
    }
  }
}
</script>

<style scoped lang='css'>
  .show{
    display: block;
  }
  .hide{
    display: none;
  }
  .question-new-container{
    padding: 20px;
  }
  .w400{
    width: 400px;
  }
  .w198{
    width: 198px;
  }
  /* 富文本 */
  .question-new-container /deep/ .ql-editor{
    height: 200px;
  }
  .question-new-container /deep/ .ql-toolbar.ql-snow{
    padding: 0 8px;
  }
  .option{
    position: relative;
    top: -25px;
    margin-right:0
  }
  .option-input{
    position: relative;
    top: -25px;
    width: 240px;
  }
  .avatar-uploader /deep/ .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    left: 5px;
    overflow: hidden;
  }
</style>
