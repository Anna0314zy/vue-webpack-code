<template>
  <el-card class="box-card question-container">
    <!-- 添加按钮模块 -->
    <el-row class="btn_wrapper">
      <el-col :span="24">
        <div class="grid-content bg-purple-dark">
          <span class="fl tip">说明：目前支持学科和关键字条件筛选</span>
          <el-button type="success" size="small" class="fr" @click="$router.push('/questions/new')"><i class="el-icon-edit"></i> 新增试题</el-button>
        </div>
      </el-col>
    </el-row>
    <!-- 搜索模块 -->
    <el-form label-width="80px" size="small" ref="searchForm" :model="requestQuestions">
      <el-row>
        <!-- 第一行 -->
        <el-col :span="6">
          <el-form-item label="学科" prop="subjectID">
            <el-select placeholder="请选择" v-model="requestQuestions.subjectID" @change="subjectChange">
              <el-option v-for="item in subjectList" :label="item.label" :value="item.value" :key="item.value"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="二级目录" prop="catalogID">
            <el-select placeholder="请选择" v-model="requestQuestions.catalogID">
              <el-option v-for="item in directoryList" :label="item.label" :value="item.value" :key="item.value"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="标签" prop="tags">
            <el-select placeholder="请选择" v-model="requestQuestions.tags">
              <!-- <el-option label="区域一" value="shanghai"></el-option> -->
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="关键字" prop="keyword">
            <el-input placeholder="根据题干搜索" v-model="requestQuestions.keyword"></el-input>
          </el-form-item>
        </el-col>
        <!-- 第二行 -->
        <el-col :span="6">
          <el-form-item label="试题类型" prop="questionType">
            <el-select placeholder="请选择" v-model="requestQuestions.questionType">
              <el-option label="单选" value="1"></el-option>
              <el-option label="多选" value="2"></el-option>
              <el-option label="简答" value="3"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="难度" prop="difficulty">
            <el-select placeholder="请选择" v-model="requestQuestions.difficulty">
              <el-option label="简单" value="1"></el-option>
              <el-option label="一般" value="2"></el-option>
              <el-option label="困难" value="3"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="方向" prop="direction">
            <el-select placeholder="请选择" v-model="requestQuestions.direction">
              <el-option label="o2o" value="o2o"></el-option>
              <el-option label="外包服务" value="外包服务"></el-option>
              <el-option label="企业服务" value="企业服务"></el-option>
              <el-option label="互联网金融" value="互联网金融"></el-option>
              <el-option label="企业咨询" value="企业咨询"></el-option>
              <el-option label="互联网" value="互联网"></el-option>
              <el-option label="电子商务" value="电子商务"></el-option>
              <el-option label="其他" value="其他"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="录入人" prop="creatorID">
            <el-select placeholder="请选择" v-model="requestQuestions.creatorID">
              <el-option label="简单" value="1"></el-option>
              <el-option label="一般" value="2"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <!-- 第三行 -->
        <el-col :span="6">
          <el-form-item label="题目备注" prop="remarks">
              <el-input v-model="requestQuestions.remarks"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="企业简称" prop="shortName">
              <el-input v-model="requestQuestions.shortName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-col :span="14" style="padding-right: 4px">
            <el-form-item label="城市" prop="province">
              <el-select placeholder="请选择" v-model="requestQuestions.province" @change="cityChange">
                <el-option v-for="item in allCitys" :label="item" :value="item" :key="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
            <el-col :span="10" style="padding-left: 4px" class="no_mg">
              <el-form-item label="" prop="city">
                <el-select placeholder="请选择" v-model="requestQuestions.city">
                  <el-option v-for="item in countyTown" :label="item" :value="item" :key="item"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
        </el-col>
        <el-col :span="6">
          <el-form-item class="to-end">
            <el-button size="small" @click="clearForm">清除</el-button>
            <el-button type="primary" size="small" @click="search">搜索</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <!-- Tab栏 -->
    <el-tabs v-model="activeName" type="card" @tab-click="tabClick">
      <el-tab-pane label="全部" name="all">
        <!-- tab顶部提示信息 -->
        <el-alert :closable="false" type="info" class="tab-top-msg"><i class="el-icon-info"></i> <span>数据一共 {{counts}} 条</span></el-alert>
        <!-- 表格 -->
        <question-table :questionList="questionList" @change-data="loadAllQuestions" v-model="isLoading" :page="requestQuestions.page" :pagesize="requestQuestions.pagesize"></question-table>
        <!-- 分页 -->
        <el-row>
          <el-col :span="24">
            <el-pagination
              class="fr"
              style="margin-top: 20px"
              background
              :page-sizes="[5, 10, 20, 50]"
              :page-size="requestQuestions.pagesize"
              layout="prev, pager, next, sizes, jumper"
              :total="counts"
              :current-page="requestQuestions.page"
              @current-change="pageChange"
              @size-change="sizeChange"
              :disabled="isLoading">
            </el-pagination>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="待审核" name="0">
        <!-- tab顶部提示信息 -->
        <el-alert :closable="false" type="info" class="tab-top-msg"><i class="el-icon-info"></i> <span>数据一共 {{counts}} 条</span></el-alert>
        <!-- 表格 -->
        <question-table :questionList="questionList" @change-data="loadAllQuestions" v-model="isLoading" :page="requestQuestions.page" :pagesize="requestQuestions.pagesize"></question-table>
        <!-- 分页 -->
        <el-row>
          <el-col :span="24">
            <el-pagination
              class="fr"
              style="margin-top: 20px"
              background
              :page-sizes="[5, 10, 20, 50]"
              :page-size="requestQuestions.pagesize"
              layout="prev, pager, next, sizes, jumper"
              :total="counts"
              :current-page="requestQuestions.page"
              @current-change="pageChange"
              @size-change="sizeChange"
              :disabled="isLoading">
            </el-pagination>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="已审核" name="1">
        <!-- tab顶部提示信息 -->
        <el-alert :closable="false" type="info" class="tab-top-msg"><i class="el-icon-info"></i> <span>数据一共 {{counts}} 条</span></el-alert>
        <!-- 表格 -->
        <question-table :questionList="questionList" @change-data="loadAllQuestions" v-model="isLoading" :page="requestQuestions.page" :pagesize="requestQuestions.pagesize"></question-table>
        <!-- 分页 -->
        <el-row>
          <el-col :span="24">
            <el-pagination
              class="fr"
              style="margin-top: 20px"
              background
              :page-sizes="[5, 10, 20, 50]"
              :page-size="requestQuestions.pagesize"
              layout="prev, pager, next, sizes, jumper"
              :total="counts"
              :current-page="requestQuestions.page"
              @current-change="pageChange"
              @size-change="sizeChange"
              :disabled="isLoading">
            </el-pagination>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="已拒绝" name="2">
        <!-- tab顶部提示信息 -->
        <el-alert :closable="false" type="info" class="tab-top-msg"><i class="el-icon-info"></i> <span>数据一共 {{counts}} 条</span></el-alert>
        <!-- 表格 -->
        <question-table :questionList="questionList" @change-data="loadAllQuestions" v-model="isLoading" :page="requestQuestions.page" :pagesize="requestQuestions.pagesize"></question-table>
        <!-- 分页 -->
        <el-row>
          <el-col :span="24">
            <el-pagination
              class="fr"
              style="margin-top: 20px"
              background
              :page-sizes="[5, 10, 20, 50]"
              :page-size="requestQuestions.pagesize"
              layout="prev, pager, next, sizes, jumper"
              :total="counts"
              :current-page="requestQuestions.page"
              @current-change="pageChange"
              @size-change="sizeChange"
              :disabled="isLoading">
            </el-pagination>
          </el-col>
        </el-row>
      </el-tab-pane>
    </el-tabs>
  </el-card>
</template>

<script>
// 引入接口方法
import { choice } from '@/api/hmmm/questions'
// 获取学科的接口
import { simple as getSubjectSimple } from '@/api/hmmm/subjects'
// 获取二级目录的接口
import { simple as getdirectorySimple } from '@/api/hmmm/directorys'
// 获取
// 引入城市
import { provinces, citys } from '@/api/hmmm/citys'
// 导入表格插件
import QuestionTable from '../components/questionTable'
export default {
  components: {
    QuestionTable
  },
  data () {
    return {
      questionList: [],
      // 学科列表
      subjectList: [],
      // 二级目录
      directoryList: [],
      // 城市
      allCitys: [],
      // 地区
      countyTown: [],
      requestQuestions: {
        subjectID: null, // 学科
        difficulty: null, // 难度
        questionType: null, // 试题类型
        tags: null, // 标签
        province: null, // 企业所在地省份
        city: null, // 企业所在城市
        keyword: null, // 关键字
        remarks: null, // 题目备注
        shortName: null, // 企业简称
        direction: null, // 方向
        creatorID: null, // 录入人
        catalogID: null, // 目录
        page: 1, // 页码
        pagesize: 5, // 每页的个数
        chkState: null // 审核状态
      },
      counts: 0, // 总条数
      activeName: 'all', // Tab栏属性
      isLoading: false // 是否显示loading效果
    }
  },
  created () {
    // 获取列表数据
    this.loadAllQuestions()
    // 获取学科数据
    this.getSubject()
    // 处理城市
    this.getCitys()
  },
  methods: {
    // 获取列表数据
    async loadAllQuestions () {
      // 调用ajax请求数据
      const res = await choice(this.requestQuestions)
      // 把获取到的数据进行赋值
      this.questionList = res.data.items
      // 赋值总条数
      this.counts = res.data.counts
      // 关闭loading效果
      this.isLoading = false
    },
    // Tab切换时触发的事件
    tabClick (tab) {
      // 把当前点击的tab携带的属性，赋值给 审核状态
      if (tab.name === 'all') {
        this.requestQuestions.chkState = null
      } else {
        this.requestQuestions.chkState = tab.name
      }
      // 重新获取数据
      this.loadAllQuestions()
    },
    // 切换页码时
    pageChange (page) {
      // 防止用户在选择搜索条件后，切换分页
      // 显示loading效果
      this.isLoading = true
      // 更新当前页码
      this.requestQuestions.page = page
      // 重新获取数据
      this.loadAllQuestions()
    },
    // 每页条数发生改变时
    sizeChange (size) {
      // 显示loading效果
      this.isLoading = true
      // 更新当前页码
      this.requestQuestions.pagesize = size
      // 重新获取数据
      this.loadAllQuestions()
    },
    // 获取搜索框中学科的值
    async getSubject () {
      const res = await getSubjectSimple()
      // 把获取到的学科列表数据进行赋值
      this.subjectList = res.data
    },
    // 选择了学科 获取 二级目录
    subjectChange (value) {
      this.getSecondDir(value)
    },
    // 获取二级目录
    async getSecondDir (value) {
      const data = {
        id: value
      }
      // 调用接口
      const res = await getdirectorySimple(data)
      this.directoryList = res.data
    },
    // 获取城市列表
    getCitys () {
      this.allCitys = provinces()
    },
    // 获取城市下的地区
    cityChange (city) {
      // 清空地区的值
      this.requestQuestions.city = null
      this.countyTown = citys(city)
    },
    // 点击搜索
    search () {
      this.isLoading = true
      this.requestQuestions.page = 1
      this.loadAllQuestions()
    },
    // 清空输入
    clearForm () {
      this.$refs.searchForm.resetFields()
      // 清空地区的数据
      this.countyTown = []
      // 重新获取数据
      this.loadAllQuestions()
    }
  }
}
</script>

<style scoped lang='css'>
.question-container{
  margin: 10px;
}
.question-container /deep/ .el-select{
  width: 100%;
}
.btn_wrapper{
  margin-bottom: 15px;
}
.tip{
  font-size: 12px;
  color: pink;
}
.to-end{
  display: flex;
  justify-content: flex-end;
}
.tab-top-msg{
  line-height: 18px;
}
.tab-top-msg i{
  font-size: 16px;
}
.tab-top-msg span{
  font-size: 13px;
}
/deep/ .el-alert .el-alert__description{
  margin: 0;
}
.no_mg /deep/ .el-form-item__content{
  margin-left: 0 !important;
}
</style>
