<template>
  <div class="pleaselist">
    <!-- 关键字搜索 -->
    <el-form :inline="true" :model="formInline" class="demo-form-inline">
      <el-form-item class="keyword" label="关键字">
        <el-input v-model="keyword" placeholder="根据编号搜索"> </el-input>
      </el-form-item>
      <div class="power">
        <el-form-item>
          <el-button @click="hClear">清除</el-button>
        </el-form-item>
        <el-form-item>
          <el-button @click="hSearch" type="primary">搜索</el-button>
        </el-form-item>
      </div>
    </el-form>
    <div
      role="alert"
      class="el-alert el-alert--info is-light"
      style="margin-bottom: 15px"
    >
      <i class="el-alert__icon el-icon-info"></i>
      <div class="el-alert__content">
        <span class="el-alert__title">数据一共{{ count }}条</span>
        <i class="el-alert__closebtn el-icon-close" style="display: none"></i>
      </div>
    </div>
    <!-- 数据页面 -->
    <el-table class="table" :data="tableData" style="width: 100%">
      <el-table-column label="序号" width="50" align="center">
          <template scope="scope">
            <span>{{(currentPage-1)*pagesize+(scope.$index + 1)}} </span>
          </template>
        </el-table-column>
      <el-table-column prop="id" label="编号" width="220"></el-table-column>
      <el-table-column label="题型">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.questionType == 1">单选</el-tag>
          <el-tag v-else-if="scope.row.questionType == 2">多选</el-tag>
          <el-tag v-else-if="scope.row.questionType == 3">简答题</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="题目编号" width="220">
        <template slot-scope="scope">
          <el-link
            @click="previewDetails(items.id)"
            v-for="(items, index) in scope.row.questionIDs"
            :key="index"
            type="primary"
            :underline="false"
            >{{ items.number }}
          </el-link>
        </template>
      </el-table-column>
      <el-table-column prop="addTime" label="录入时间" width="180">
      </el-table-column>
      <el-table-column prop="totalSeconds" label="答题时间(S)">
      </el-table-column>
      <el-table-column prop="accuracyRate" label="正确率(%)"> </el-table-column>
      <el-table-column prop="userName" label="录入人"> </el-table-column>
      <el-table-column prop="operation" label="操作">
        <template slot-scope="scope">
          <el-button
            type="danger"
            icon="el-icon-delete"
            circle
            plain
            @click="hDelete(scope.row)"
          >
          </el-button>
        </template>
      </el-table-column>
      <!-- 分页 -->
    </el-table>
    <div class="block">
      <el-pagination
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
        :current-page="currentPage"
        :page-size="pagesize"
        background
        layout="prev, pager, next, sizes, jumper"
        :page-sizes="[20, 30, 50, 100]"
        :total="count"
      >
      </el-pagination>
    </div>
    <el-dialog title="题目预览" :visible.sync="dialogVisible" width="50%">
      <el-row>
        <el-col :span="6">【题型】：
          <span v-if="preview.questionType == 1">单选</span>
          <span v-else-if="preview.questionType == 2">多选</span>
          <span v-else-if="preview.questionType == 3">简答题</span>
        </el-col>
        <el-col :span="6">【编号】：{{preview.id}}</el-col>
        <el-col :span="6">【难度】：{{preview.difficulty}}
          <span v-if="preview.difficulty == 1">简单</span>
          <span v-else-if="preview.difficulty == 2">一般</span>
          <span v-else-if="preview.difficulty == 3">困难</span>
        </el-col>
        <el-col :span="6">【标签】：{{preview.tags}}</el-col>
        <el-col :span="6">【学科】：{{preview.subjectName}}</el-col>
        <el-col :span="6">【目录】：{{preview.directoryName}}</el-col>
        <el-col :span="6">【方向】：{{preview.direction}}</el-col>
      </el-row>
      <hr>
      <!-- 简答 -->
      <el-row>
        <el-col :span="24">【题干】：</el-col>
        <div style="color: blue" v-html="preview.question">
        </div>
      </el-row>
      <!-- 单选 -->
      <el-row v-if="preview.questionType == 1">
        <el-col :span="24">单选题 选项：（以下选中的选项为正确答案）</el-col>
        <el-form>
          <el-form-item>
            <el-radio-group v-model="isRight" @change="radioChang">
              <div v-for="item in preview.options" :key="item.id" style="padding: 8px 0">
                <el-radio :label="item.isRight">{{item.title}}</el-radio>
              </div>
            </el-radio-group>
          </el-form-item>
        </el-form>
      </el-row>
      <!-- 多选 -->
      <el-row v-else-if="preview.questionType == 2">
        <el-col :span="24">多选题 选项：（以下选中的选项为正确答案）</el-col>
        <el-form>
          <el-form-item>
            <el-checkbox-group v-model="multipleChoice" @change="checkboxChang">
              <div v-for="item in preview.options" :key="item.id">
                <el-checkbox :label="item.title"></el-checkbox>
              </div>
            </el-checkbox-group>
          </el-form-item>
        </el-form>
      </el-row>
      <hr>
      <el-row>
        <el-col :span="24">
          【参考答案】：
          <el-button v-if="this.videoUrl !== ''" type="danger" size="small" @click="showVideoAnswer" style="backgrouond: black">视频答案预览</el-button>
        </el-col>
        <el-col :span="24" v-if="videoIsShow">
          <video :src="videoUrl" width="400px" controls="controls" autoplay></video>
        </el-col>
      </el-row>
      <hr>
      <el-row>
        <el-col :span="24">
          【答案解析】：
          <div v-html="preview.answer"></div>
        </el-col>
      </el-row>
      <hr>
      <el-row>
        <el-col :span="24">
          【题目备注】：{{preview.remarks}}
        </el-col>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">关 闭</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { randoms, removeRandoms, detail } from '@/api/hmmm/questions'
export default {
  data () {
    return {
      keyword: '',
      dialogVisible: false,
      preview: {},
      videoIsShow: false, // 视频是否弹出
      videoUrl: '', // 视频地址
      isRight: 1, // 判断单选 1 是选中
      multipleChoice: [], // 用来存放多选的名称
      checkMultipleChoice: [], // 用来赋值回多选，不让用户进行修改
      count: 0, // 总条数
      currentPage: 1,
      pagesize: 20,
      tableData: [],
      formInline: {}
    }
  },
  created () {
    this.loadComments()
  },
  methods: {
    // 分页
    handleCurrentChange (curpage) {
      this.currentPage = curpage
      this.loadComments()
    },
    handleSizeChange (page) {
      this.pagesize = page
      this.loadComments()
    },
    async loadComments () {
      const data = {
        page: this.currentPage,
        pagesize: this.pagesize,
        keyword: this.keyword
      }
      const res = await randoms(data)
      console.log(res)
      this.tableData = res.data.items
      this.count = res.data.counts
    },
    // 删除操作
    hDelete (row) {
      console.log('删除的数据是', row)
      const id = row.id
      console.log(id)
      // 确认弹框
      this.$confirm('确定删除', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const data = { id }
        // 删除数据
        removeRandoms(data).then((res) => {
          this.$message({
            message: '删除成功!',
            type: 'success'
          })
        })
        this.loadComments()
      })
    },
    // 匹配关键字
    hClear () {
      // 清除输入框
      this.keyword = ''
    },
    hSearch () {
      // 匹配关键字
      this.currentPage = 1
      this.loadComments()
    },
    previewDetails (id) {
      this.dialogVisible = true
      this.getPreviewData(id)
      console.log(id)
    },
    async getPreviewData (id) {
      // 请求接口，把请求过来的数据 赋值到data中
      // console.log(row)
      const res = await detail({ id })
      this.preview = res.data
      console.log(res)
      // 赋值视频链接
      this.videoUrl = res.data.videoURL
      // 判断当前有没有多选
      if (this.preview.questionType === '2') {
        // 处理多选的数据
        this.setMultipleChoice(this.preview.options)
      }
    },
    // 处理多选数据
    setMultipleChoice (obj) {
      // 通个循环找出 当前 选中的数值，存在一个数组中
      obj.forEach((item) => {
        if (item.isRight === 1) {
          this.multipleChoice.push(item.title)
          this.checkMultipleChoice.push(item.title)
        }
      })
    },
    // 点击视频答案预览 按钮 显示视频
    showVideoAnswer () {
      // 判断当前视频地址存在不
      if (this.videoUrl !== '') {
        this.videoIsShow = true
      }
    },
    // 切换单选时
    radioChang () {
      // 每次改变的时候，强制让单选的value变为1，让他不能改变
      this.isRight = 1
    },
    // 切换多选时
    checkboxChang () {
      this.multipleChoice = this.checkMultipleChoice
    }
  },
  watch: {
    // 监听弹出框是否显示
    dialogVisible (newVal, oldVal) {
      // 如果弹出框关闭了
      if (!newVal) {
        // 把视频隐藏
        this.videoIsShow = false
        // 清空当前视频地址
        this.videoUrl = ''
      }
    }
  }
}
</script>

<style scoped>
.pleaselist {
  margin: 10px 10px;
  padding: 0 10px;
  background-color: #ffffff;
}
.demo-form-inline {
  padding: 20px 0;
}
.keyword {
  padding: 0 20px;
}
.power {
  float: right;
}
.block {
  text-align: right;
  height: 60px;
  padding-top: 15px;
}
</style>
