<template>
<div class="add-form">
    <el-dialog :title="formData.text+formData.pageTitle"  :visible.sync="formData.dialogFormVisible">
      <div v-if="formData.text != '预览'">
       <el-form
       ref="myForm"
       :rules="ruleInline"
       :model="formData"
       label-position="left"
       label-width="100px"
       style="width: 100%; ">
          <el-form-item label="文章标题:" prop="title">
          <el-input placeholder="请输入文章标题" v-model="formData.title"></el-input>
        </el-form-item>
         <el-form-item label="文章内容:" class="articles" prop="articleBody">
             <quill-editor  :options="editorOption" v-model="formData.articleBody"></quill-editor>
        </el-form-item>
        <el-form-item label="视频地址:">
         <el-input placeholder="请输入视频地址" v-model="formData.videoURL"></el-input>
        </el-form-item>
       </el-form>
       <!-- 取消和确认按钮 -->
        <div slot="footer" class="footer">
        <el-button @click="closeShell">取消</el-button>
        <el-button type="primary" @click="reviseArticle">确认</el-button>
        </div>
        </div>
        <!-- 切换到预览文章 -->
        <div class="preview-article" v-else>
          <div class="title">{{formData.title}}</div>
          <div class="state"><span>{{formData.createTime | fFormDate}}</span><span>{{formData.username}}</span><span><i class="el-icon-view"></i></span><span>{{formData.state}}</span></div>
          <div class="article-body" v-html="formData.articleBody"></div>
        </div>
    </el-dialog>
</div>

</template>

<script>
// 导入样式
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
// 导入组件
import { update, add } from '@/api/hmmm/articles'
import { quillEditor } from 'vue-quill-editor'
export default {
  name: 'articlesAdd',
  props: ['value'],
  data () {
    return {
      // 富文本配置对象
      editorOption: {
        // 占位配置
        placeholder: '',
        modules: {
          // 配置工具栏
          toolbar: [
            ['bold', 'italic', 'underline', 'strike'],
            [{ list: 'ordered' }, { list: 'bullet' }],
            ['blockquote'],
            ['code-block', 'image']
          ]
        }
      },
      // 表单验证
      ruleInline: {
        title: [
          { required: true, message: '请输入文章标题', trigger: 'blur' }
        ],
        articleBody: [
          { required: true, message: '请输入文章内容', trigger: 'blur' }
        ]
      },
      formData: this.value

    }
  },
  components: {
    quillEditor
  },
  filters: {
    // 时间格式转换
    fFormDate (val) {
      const time = new Date(val)
      const y = time.getFullYear() < 10 ? '0' + time.getFullYear() : time.getFullYear()
      const m = (time.getMonth() + 1) < 10 ? '0' + (time.getMonth() + 1) : (time.getMonth() + 1)
      const d = time.getDate() < 10 ? '0' + time.getDate() : time.getDate()
      const h = time.getHours() < 10 ? '0' + time.getHours() : time.getHours()
      const mn = time.getMinutes() < 10 ? '0' + time.getMinutes() : time.getMinutes()
      const s = time.getSeconds() < 10 ? '0' + time.getSeconds() : time.getSeconds()
      return y + '-' + m + '-' + d + ' ' + h + ':' + mn + ':' + s
    }
  },
  // 监听数据
  watch: {
    // 清除表单验证
    'formData.dialogFormVisible' (newData, oldData) {
      if (newData) {
        this.$nextTick(() => {
          if (this.formData.text !== '预览') { this.$refs.myForm.clearValidate() }
        })
      }
    }
  },
  methods: {
    // 关闭弹层
    closeShell () {
      this.formData.dialogFormVisible = false
    },
    // 发送请求
    reviseArticle () {
      // 验证规则
      this.$refs.myForm.validate(valid => {
        if (valid) {
          if (this.formData.text === '新增') {
            try {
              const { title, videoURL, articleBody } = this.formData
              add({ title, videoURL, articleBody })
              this.$message.success('新增文章成功')
              this.formData.dialogFormVisible = false
            } catch (err) {
              console.log(err)
              this.$message.error('请求失败')
            }
          } else {
            try {
              update(this.formData)
              this.$message.success('修改文章成功')
              this.formData.dialogFormVisible = false
            } catch (err) {
              console.log(err)
              this.$message.error('请求失败')
            }
          }
        }
      })
    }
  }
}
</script>

<style scoped lang='css'>
/deep/ .ql-editor{
  height: 300px;
}
.title {
  font-size: 20px;
  font-weight: 800;
}
.state {
  line-height: 34px;
}
.state span {
  margin-right: 9px;
}
.article-body {
  border-top: 2px dotted #a7a2a2;
  padding: 10px;
  background: #f5f5f5;
}
/deep/ .footer {
  text-align: center;
}
</style>
