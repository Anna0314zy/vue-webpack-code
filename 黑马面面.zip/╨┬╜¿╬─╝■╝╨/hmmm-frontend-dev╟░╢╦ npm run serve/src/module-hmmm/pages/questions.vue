<template>
  <el-card class="box-card question-container">
    <!-- 顶部提示文字和按钮 -->
    <div class="header-nav">
      <span class="instructions">说明：目前支持学科和关键字条件筛选</span>
      <el-button
        type="success"
        class="fr"
        icon="el-icon-edit"
        size="small"
        @click="$router.push('new')"
        >新增试题</el-button
      >
    </div>
    <!-- 搜索表单 -->
    <el-form
      :model="requestParams"
      ref="requestParams"
      label-width="80px"
      size="small"
    >
      <el-row>
        <el-col :span="6">
          <el-form-item label="学科" prop="subjectID">
            <el-select
              @keyup.enter="hsearchForm"
              @change="handleSubject(requestParams.subjectID)"
              v-model="requestParams.subjectID"
              placeholder="请选择"
            >
              <el-option
                v-for="item in subject"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="二级目录" prop="catalog">
            <el-select
              @keyup.enter="hsearchForm"
              v-model="requestParams.catalogID"
              placeholder="请选择"
            >
              <el-option
                v-for="item in catalog"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="标签" prop="tags">
            <el-select
              @keyup.enter="hsearchForm"
              v-model="requestParams.tags"
              placeholder="请选择"
            >
              <el-option
                v-for="item in tags"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="关键字">
            <el-input
              @keyup.enter="hsearchForm"
              v-model="requestParams.keyword"
              placeholder="根据题干搜索"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="试题类型" prop="questionType">
            <el-select
              @keyup.enter="hsearchForm"
              v-model="requestParams.questionType"
              placeholder="请选择"
            >
              <el-option label="单选" :value="1"></el-option>
              <el-option label="多选" :value="2"></el-option>
              <el-option label="一般" :value="3"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="难度" prop="difficulty">
            <el-select
              @keyup.enter="hsearchForm"
              v-model="requestParams.difficulty"
              placeholder="请选择"
            >
              <el-option label="简单" :value="1"></el-option>
              <el-option label="一般" :value="2"></el-option>
              <el-option label="困难" :value="3"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="方向" prop="direction">
            <el-select
              @keyup.enter="hsearchForm"
              v-model="requestParams.direction"
              placeholder="请选择"
            >
              <el-option label="o2o" value="o2o"></el-option>
              <el-option label="外包服务" value="外包服务"></el-option>
              <el-option label="企业服务" value="企业服务"></el-option>
              <el-option label="互联网金融" value="互联网金融"></el-option>
              <el-option label="企业金融" value="企业金融"></el-option>
              <el-option label="互联网" value="互联网"></el-option>
              <el-option label="电子商务" value="电子商务"></el-option>
              <el-option label="其他" value="其他"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="录入人" prop="creatorID">
            <el-select
              @keyup.enter="hsearchForm"
              v-model="requestParams.creatorID"
              placeholder="请选择"
            >
              <el-option
                v-for="item in creatorList"
                :key="item.id"
                :label="item.username"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="题目备注" prop="remarks">
            <el-input
              @keyup.enter="hsearchForm"
              v-model="requestParams.remarks"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="企业简称" prop="shortName">
            <el-input
              @keyup.enter="hsearchForm"
              v-model="requestParams.shortName"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="城市" class="city">
            <el-select
              @keyup.enter="hsearchForm"
              @change="handleProvince"
              v-model="requestParams.province"
              prop="province"
              placeholder="请选择"
              class="left-el-select"
            >
              <el-option
                v-for="item in province"
                :key="item.value"
                :label="item"
                :value="item"
                filterable
              ></el-option>
            </el-select>
            <el-select
              @keyup.enter="hsearchForm"
              v-model="requestParams.city"
              prop="city"
              placeholder="请选择"
              class="left-el-select"
            >
              <el-option
                v-for="item in cityDate"
                :key="item"
                filterable
                :label="item"
                :value="item"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item class="fr btn-end">
            <el-button size="mini" @click="hclearForm">清除</el-button>
            <el-button size="mini" @click="hsearchForm" type="primary"
              >搜索</el-button
            >
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <!-- 数据记录 -->
    <el-alert
      v-if="alertText !== ''"
      :title="alertText"
      type="info"
      class="alert"
      :closable="false"
      show-icon
    ></el-alert>
    <!-- 表格区域 -->
    <el-table
      :data="tableData"
      v-loading="listLoading"
      :key="tableKey"
      style="width: 100%"
    >
      <el-table-column label="序号" width="50" align="center">
        <template scope="scope">
          <span
            >{{
              (requestParams.page - 1) * requestParams.pagesize +
              (scope.$index + 1)
            }}
          </span>
        </template>
      </el-table-column>
      <el-table-column prop="number" label="试题编号" align="center">
      </el-table-column>
      <el-table-column prop="subject" label="学科" align="center" width="150px">
      </el-table-column>
      <el-table-column prop="catalog" label="目录" align="center" width="150px">
      </el-table-column>
      <el-table-column
        prop="questionType"
        label="题型"
        align="center"
        width="150px"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.questionType == 1">单选</span>
          <span v-else-if="scope.row.questionType == 2">多选</span>
          <span v-else>简单</span>
        </template>
      </el-table-column>
      <el-table-column prop="question" label="题干" align="center">
        <template slot-scope="scope">
          <span v-html="scope.row.question"></span>
        </template>
      </el-table-column>
      <el-table-column prop="addDate" label="录入时间" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.addDate | parseTimeByString }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="difficulty" label="难度" align="center">
        <template slot-scope="scope">
          <span v-if="scope.row.difficulty == 1">简单</span>
          <span v-else-if="scope.row.difficulty == 2">一般</span>
          <span v-else>困难</span>
        </template>
      </el-table-column>
      <el-table-column prop="creator" label="录入人" align="center">
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-tooltip content="预览" effect="light">
            <el-button
              @click="hlook(scope.row.id)"
              plain
              size="small"
              type="primary"
              icon="el-icon-view"
              circle
            >
            </el-button>
          </el-tooltip>
          <el-tooltip content="编辑" effect="light">
            <el-button
              @click="hEdit(scope.row.id)"
              plain
              size="small"
              type="success"
              icon="el-icon-edit"
              circle
            >
            </el-button>
          </el-tooltip>
          <el-tooltip content="删除" effect="light">
            <el-button
              @click="hDel(scope.row.id)"
              plain
              size="small"
              type="danger"
              icon="el-icon-delete"
              circle
            >
            </el-button>
          </el-tooltip>
          <el-tooltip content="加入精选" effect="light">
            <el-button
              @click="hAdd(scope.row)"
              plain
              size="small"
              type="warning"
              icon="el-icon-check"
              circle
            >
            </el-button>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <el-pagination
      v-loading="isLoading"
      @size-change="hSizeChange"
      @current-change="hCurrentChange"
      :current-page="requestParams.page"
      :page-size="requestParams.pagesize"
      class="fr pagination"
      background
      :page-sizes="[5, 10, 20, 50]"
      layout="prev, pager, next,sizes, jumper"
      :total="total"
    >
    </el-pagination>
    <!-- 预览弹出框 -->
    <el-dialog
      title="题目预览"
      :visible.sync="dialogVisible"
      width="900px"
      class="dialog_list"
    >
      <el-row>
        <el-col :span="6"
          >【题型】：
          <span v-if="preview.questionType == 1">单选</span>
          <span v-else-if="preview.questionType == 2">多选</span>
          <span v-else-if="preview.questionType == 3">简答题</span>
        </el-col>
        <el-col :span="6">【编号】：{{ preview.id }}</el-col>
        <el-col :span="6"
          >【难度】：{{ preview.difficulty }}
          <span v-if="preview.difficulty == 1">简单</span>
          <span v-else-if="preview.difficulty == 2">一般</span>
          <span v-else-if="preview.difficulty == 3">困难</span>
        </el-col>
        <el-col :span="6">【标签】：{{ preview.tags }}</el-col>
        <el-col :span="6">【学科】：{{ preview.subjectName }}</el-col>
        <el-col :span="6">【目录】：{{ preview.directoryName }}</el-col>
        <el-col :span="6">【方向】：{{ preview.direction }}</el-col>
      </el-row>
      <hr />
      <!-- 简答 -->
      <el-row>
        <el-col :span="24">【题干】：</el-col>
        <div style="color: blue" v-html="preview.question"></div>
      </el-row>
      <!-- 单选 -->
      <el-row v-if="preview.questionType == 1">
        <el-col :span="24">单选题 选项：（以下选中的选项为正确答案）</el-col>
        <el-form>
          <el-form-item>
            <el-radio-group v-model="isRight" @change="radioChange">
              <div
                v-for="item in preview.options"
                :key="item.id"
                style="padding: 8px 0"
              >
                <el-radio :label="item.isRight">{{ item.title }}</el-radio>
              </div>
            </el-radio-group>
          </el-form-item>
        </el-form>
      </el-row>
      <!-- 多选 -->
      <el-row v-else-if="preview.questionType == 2">
        <el-col :span="24">多选题 选项：（以下选中的选项为正确答案）</el-col>
        <el-form>
          <el-form-item>
            <el-checkbox-group
              v-model="multipleChoice"
              @change="checkboxChange"
            >
              <div v-for="item in preview.options" :key="item.id">
                <el-checkbox :label="item.title"></el-checkbox>
              </div>
            </el-checkbox-group>
          </el-form-item>
        </el-form>
      </el-row>
      <hr />
      <el-row>
        <el-col :span="24">
          【参考答案】：
          <el-button
            v-if="this.videoUrl !== ''"
            type="danger"
            size="small"
            @click="showVideoAnswer"
            style="backgrouond: black"
            >视频答案预览</el-button
          >
        </el-col>
        <el-col :span="24" v-if="videoIsShow">
          <video
            :src="videoUrl"
            width="400px"
            controls="controls"
            autoplay
          ></video>
        </el-col>
      </el-row>
      <hr />
      <el-row>
        <el-col :span="24">
          【答案解析】：
          <div v-html="preview.answer"></div>
        </el-col>
      </el-row>
      <hr />
      <el-row>
        <el-col :span="24"> 【题目备注】：{{ preview.remarks }} </el-col>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false"
          >取 消</el-button
        >
      </span>
    </el-dialog>
  </el-card>
</template>
<script>
import { provinces, citys } from '@/api/hmmm/citys.js'
import { simple as getUserInfo } from '@/api/base/users.js'
import { simple as getTagsList } from '@/api/hmmm/tags.js'
import { simple as getSubjectList } from '@/api/hmmm/subjects.js'
import { simple as getDirectorysList } from '@/api/hmmm/directorys.js'
// import { list } from '@api/base/users.js'
import { list, remove, detail, choiceAdd } from '@/api/hmmm/questions.js'
// eslint-disable-next-line no-unused-vars
import { parseTimeByString } from '@/filters/index.js'

export default {
  name: 'questions',
  props: [],
  data () {
    return {
      isLoading: false,
      dialogVisible: false, // 显示预览的弹出框
      videoIsShow: false, // 是否显示视频
      preview: {},
      videoUrl: '', // 视频地址
      isRight: 1, // 判断单选 1 是选中
      multipleChoice: [], // 用来存放多选的名称
      checkMultipleChoice: [], // 用来赋值回多选，不让用户进行修改
      tags: [],
      province: [], // 省
      cityDate: [], // 市
      creator: [], // 用户
      total: null,
      listLoading: true,
      tableKey: '0',
      alertText: '',
      tableData: [], // 表格
      catalog: [], // 二级目录
      creatorList: [], // 用户列表
      subject: [], // 学科列表
      requestParams: {
        page: 1,
        pagesize: 5,
        direction: null,
        shortName: null,
        remarks: null,
        province: null,
        difficulty: null,
        city: null,
        catalogID: null,
        keyword: null,
        subjectID: null,
        creatorID: null,
        directorysID: null,
        tags: null,
        questionType: null
      }
    }
  },
  watch: {
    // 监听弹出框是否显示
    dialogVisible (newVal) {
      // 如果弹出框关闭了
      if (!newVal) {
        // 把视频隐藏
        this.videoIsShow = false
        // 清空当前视频地址
        this.videoUrl = ''
      }
    }
  },
  created () {
    this.inittableDate()
    this.getSubject()
    this.getUserList()
    this.getCityData()
  },
  mounted () {
    console.log(this.$refs)
  },
  methods: {
    // 预览
    hlook (id) {
      // 显示弹出框
      this.dialogVisible = true
      this.getPreviewData(id)
    },
    // 获取详情数据
    async getPreviewData (id) {
      const data = {
        id
      }
      // 请求接口，把请求过来的数据 赋值到data中
      const res = await detail(data)
      this.preview = res.data
      // 赋值视频链接
      this.videoUrl = res.data.videoURL
      // 判断当前有没有多选
      if (this.preview.questionType === '2') {
        // 处理多选的数据
        this.setMultipleChoice(this.preview.options)
      }
    },
    // 处理多选数据
    setMultipleChoice (obj) {
      // 通个循环找出 当前 选中的数值，存在一个数组中
      obj.forEach((item) => {
        if (item.isRight === 1) {
          this.multipleChoice.push(item.title)
          this.checkMultipleChoice.push(item.title)
        }
      })
    },
    // 点击视频答案预览 按钮 显示视频
    showVideoAnswer () {
      // 判断当前视频地址存在不
      if (this.videoUrl) {
        this.videoIsShow = true
      }
    },
    // 切换单选时
    radioChange () {
      // 每次改变的时候，强制让单选的value变为1，让他不能改变
      this.isRight = 1
    },
    // 切换多选时
    checkboxChange () {
      this.multipleChoice = this.checkMultipleChoice
    },
    // 获取省
    getCityData: function () {
      this.province = provinces()
    },
    // 选省获取到市
    handleProvince: function (e) {
      this.cityDate = citys(e)
      console.log(this.cityDate)
      this.requestParams.city = this.cityDate[0]
    },
    // 清除表单数据
    hclearForm () {
      this.$refs.requestParams.resetFields()
      this.requestParams = {}
      this.getList()
    },
    // 搜索信息
    hsearchForm () {
      this.page = 1
      this.getList()
    },
    // 初始数据
    inittableDate () {
      this.getList()
    },
    // 编辑
    hEdit (row) {
      const id = row
      this.$confirm('此操作将进行试题编辑 ' + ', 是否继续?', '提示', {
        type: 'warning'
      })
        .then(() => {
          this.$router.push('/questions/new?id=' + id)
        })
        .catch(() => {
          this.$message.info('已取消操作!')
        })
    },
    // 删除
    hDel (row) {
      const id = row
      this.$confirm('此操作将永久删除 ' + ', 是否继续?', '提示', {
        type: 'warning'
      })
        .then(() => {
          const data = { id }
          remove(data).then((res) => {
            this.$message.success('删除成功')
            this.getList()
          })
        })
        .catch(() => {
          this.$message.info('已取消操作!')
        })
    },
    // 加入精选
    hAdd (row) {
      this.$confirm('此操作将把试题加入到精选 ' + ', 是否继续?', '提示', {
        type: 'warning'
      })
        .then(() => {
          const choiceState = 1
          const id = row.id
          const data = {
            choiceState,
            id
          }
          // 接口调用
          choiceAdd(data)
          this.$router.push('choice')
          this.$message.success('加入精选题库成功')
        })
        .catch(() => {
          this.$message.info('已取消操作!')
        })
    },
    // 获取列表数据
    async getList () {
      const res = await list(this.requestParams)
      this.tableData = res.data.items
      this.total = res.data.counts
      this.alertText = `数据一共${this.total}条`
      this.listLoading = false
      this.isLoading = false
    },
    // 获取学科列表
    async getSubject (params) {
      const res = await getSubjectList()
      this.subject = res.data
    },
    // 根据学科列表渲染二级目录和便签列表
    async handleSubject (id) {
      const res = await getDirectorysList({ subjectID: id })
      const restag = await getTagsList({ subjectID: id })
      this.catalog = res.data
      this.tags = restag.data
    },
    // 获取用户列表
    async getUserList () {
      const res = await getUserInfo()
      this.creatorList = res.data
    },
    // 每页显示信息条数
    hSizeChange (val) {
      this.requestParams.pagesize = val
      if (this.requestParams.page === 1) {
        this.getList(this.requestParams)
        this.isLoading = true
      }
    },
    // 进入某一页
    hCurrentChange (val) {
      this.requestParams.page = val
      this.getList()
      this.isLoading = true
    }
  }
}
</script>

<style scoped>
.header-nav {
  margin: 20px;
}
.question-container {
  margin: 10px;
}
/* .question-container /deep/ .el-select{
  width: 100%;
} */
.pagination {
  margin: 10px;
}
.alert {
  margin: 10px 0;
}
.instructions {
  font-size: 12px;
  color: pink;
}
.el-form {
  padding: 20px;
}
.el-form-item {
  display: flex;
}
.el-form /deep/ .el-form-item__content {
  flex:1!important;
  margin-left: 0px!important;
}

.el-form-item__content .el-select {
  width: 100%
}
.box-card {
  margin: 10px;
}
.box-card /deep/ .el-select{
  width: 100%;
}
.no_mg /deep/ .el-form-item__content{
  margin-left: 0 !important;
}
.el-form-item__content .el-select.el-select--small {
  width: 100%;
}
.el-form-item__content .left-el-select{
  width: 50%!important;
}
</style>
