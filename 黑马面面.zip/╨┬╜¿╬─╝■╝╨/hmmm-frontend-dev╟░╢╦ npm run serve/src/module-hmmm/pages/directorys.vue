<template>
  <div class="directorys-container">
    <el-card class="box-card">
      <!--================ 面包屑 : 学科跳转 目录 =======================-->
      <div slot="header" class="clearfix" v-if="$route.query.id">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>学科管理</el-breadcrumb-item>
          <el-breadcrumb-item>{{cardName}}</el-breadcrumb-item>
          <el-breadcrumb-item>目录管理</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <!-- ================== 1. 表头 ================== -->
      <!-- 目录名称 -->
      <el-row>
        <el-col :span="18">
          <el-form  :inline="true" label-width="80px" class="demo-form-inline">
           <el-form-item label="目录名称" prop="directoryName">
             <el-input  style="width: 200px;" v-model="requestParameters.directoryName"></el-input>
           </el-form-item>

           <el-form-item label="状态" prop="state">
             <el-select class="filter-item" style="width: 220px;" placeholder="请选择"
              v-model="requestParameters.state">
                    <el-option label="禁用" :value="0"></el-option>
                    <el-option label="启用" :value="1"></el-option>
             </el-select>
             <el-button size="small" style="margin-left:10px;" @click="clearInput">清除</el-button>
             <el-button type="primary" size="small" @click="searchInput">搜索</el-button>
           </el-form-item>
          </el-form>
        </el-col>
      <!-- 新增学科按钮 -->
        <el-col :span="6">
          <el-button
                class="filter-item fr"
                size="small"
                style="margin-left: 10px;"
                type="success"
                icon="el-icon-edit"
                @click="hAddDirectory"
              >新增目录</el-button>
          <el-button
          v-if="$route.query.id"
              class="filter-item fr"
              size="medium"
              type="text"
              icon="el-icon-back"
              @click="$router.push('/subjects/list')"
              >返回学科</el-button>
        </el-col>
      </el-row>
      <!--============== 灰色消息提示 ==================-->
       <el-alert
          v-if="alertText !== ''"
          :title="alertText"
          show-icon
          :closable="false"
          type="info"
          style="margin-bottom: 15px">
       </el-alert>
       <!--================== 2. 表格 ==================-->
       <el-table  style="width: 100%;" :data="directoryList" v-loading="isLoading">
            <el-table-column align="center" label="序号">
            <template slot-scope="scope">
              <span>{{(requestParameters.page - 1 ) * requestParameters.pagesize + ( scope.$index + 1 ) }}</span>
            </template>
          </el-table-column>

          <el-table-column align="center" label="所属学科">
            <template slot-scope="scope">
              <span>{{ scope.row.subjectName }}</span>
            </template>
          </el-table-column>

          <el-table-column align="center" label="目录名称">
            <template slot-scope="scope">
              <span>{{scope.row.directoryName}}</span>
            </template>
          </el-table-column>

          <el-table-column align="center" label="创建者">
            <template slot-scope="scope">
              <span>{{scope.row.username}}</span>
            </template>
          </el-table-column>

          <el-table-column align="center" label="创建日期">
            <template slot-scope="scope">
              <span>{{scope.row.addDate}}</span>
            </template>
          </el-table-column>

          <el-table-column align="center" label="面试题数量">
            <template slot-scope="scope">
              <span>{{scope.row.totals}}</span>
            </template>
          </el-table-column>

          <el-table-column align="center" label="状态">
            <template slot-scope="scope">
              <span v-if="scope.row.state===1">启用</span>
              <span v-else>禁用</span>
            </template>
          </el-table-column>

          <!-- 操作按钮 -->
          <el-table-column
            align="center"
            label="操作"
            width="280"
            class-name="small-padding fixed-width">
            <template slot-scope="scope">
               <el-button type="text"
                @click="handleStatus(scope.row)" >
                <span>{{scope.row.state==0?'启用':'禁用'}}</span>
              </el-button>
              <el-button type="text"
              :disabled="scope.row.state==0 ? false:true"
              @click="hEditRev(scope.row.id)">修改</el-button>
              <el-button type="text"
              @click="hEditDel(scope.row.id)"
              v-if="scope.row.status!='deleted'" :disabled="scope.row.state==0 ? false:true">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <!-- 分页 -->
        <div class="pagination" style="margin-top:20px;text-align: right;">
          <div class="pages">
            <el-pagination
             background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="Number(requestParameters.page)"
            :total="Number(total)"
            :page-size="Number(requestParameters.pagesize)"
            :page-sizes="[10, 20, 30, 50]"
            layout=" prev, pager, next,sizes, jumper"
            :disabled="isLoading"
            ></el-pagination>
          </div>
        </div>
        <!--================== 弹框 : 添加数据 =====================-->
          <el-dialog
               title="目录"
               :visible.sync="centerDialogVisible"
               width="400px"
               :destroy-on-close="true"
               center>
               <el-form label-width="80px"
                :rules="ruleInline"
                ref="dataForm"
                :model="formData">

                 <el-form-item label="所属学科" prop="subjectID" v-if="!$route.query.id">
                  <el-select  style="width:270px"
                   placeholder="请选择"
                   v-model="formData.subjectID">
                   <el-option v-for="subject in subjectList"
                   :key="subject.value"
                   :value="subject.value"
                   :label="subject.label"></el-option>
                  </el-select>
                  </el-form-item>

                  <el-form-item label="目录名称" prop="directoryName">
                  <el-input  placeholder="请输入目录名称"
                  v-model="formData.directoryName"></el-input>
                  </el-form-item>

                 <el-form-item>
                 <span class="dialog-footer">
                  <el-button @click="hCancel">取 消</el-button>
                  <el-button type="primary" @click="confirm" :loading="isLoading">确 定</el-button>
               </span>
               </el-form-item>
               </el-form>
          </el-dialog>
        <!--==================== 弹框 : 修改数据 ===================-->
          <el-dialog
               title="目录"
               :visible.sync="editDialogVisible"
               width="400px"
               :destroy-on-close="true"
               center>
               <el-form label-width="80px"
                :rules="ruleInline"
                ref="dataForm"
                :model="formData">

                 <el-form-item label="所属学科" prop="subjectID"  v-if="!$route.query.id">
                  <el-select  style="width:270px"
                   placeholder="请选择"
                   v-model="formData.subjectID">
                   <el-option v-for="subject in subjectList"
                   :key="subject.value"
                   :value="subject.value"
                   :label="subject.label"></el-option>
                  </el-select>
                  </el-form-item>

                  <el-form-item label="目录名称" prop="directoryName">
                  <el-input  placeholder="请输入目录名称"
                  v-model="formData.directoryName"></el-input>
                  </el-form-item>

                 <el-form-item>
                 <span class="dialog-footer">
                  <el-button @click="hCancel">取 消</el-button>
                  <el-button type="primary" @click="editconfirm" :loading="isLoading">确 定</el-button>
               </span>
               </el-form-item>
               </el-form>
          </el-dialog>
    </el-card>
  </div>
</template>

<script>
import { list, remove, changeState, add, update, detail } from '@/api/hmmm/directorys'
import { simple } from '@/api/hmmm/subjects'
export default {
  name: 'directory',
  data () {
    return {
      cardName: '', // 面包屑
      isLoading: false, // 加载
      alertText: '', // 灰色消息提示
      directoryList: [], // 目录数据
      subjectList: [], // 新增所属学科
      centerDialogVisible: false, // 新增弹出框
      editDialogVisible: false, // 修改弹出框
      jumpDialogVisible: false, // 学科 跳转 的 新增弹出框
      total: null, // 页数
      editId: null, // 修改需要的Id
      requestParameters: {
        directoryName: null, // 搜索关键字
        // 请求页数
        page: 1,
        pagesize: 10,
        state: null, // 禁用 启用 输入框
        subjectID: null
      },
      formData: { // 添加输入框
        subjectID: null, // 学科id
        directoryName: '' // 目录
      },
      ruleInline: { // 检验
        directoryName: [
          { required: true, message: '请输入目录名称', trigger: 'blur' }
        ]
      }
    }
  },

  methods: {
    // 10.启用 禁用
    async handleStatus (val) {
      const data = {
        id: val.id,
        state: val.state === 0 ? 1 : 0
      }
      try {
        await changeState(data)
        this.loadDirectory()
        this.$message.success('操作成功')
      } catch (err) {
        this.$message.error('操作失败')
        console.log(err)
      }
    },
    // 9.删除数据
    hEditDel (user) {
      this.$confirm('此操作将永久删除用户 ' + ', 是否继续?', '提示', {
        type: 'warning'
      })
        .then(async () => {
          await remove({ id: user })
            .then((response) => {
              this.$message.success('成功删除了用户 ' + '!')
              this.directoryList.splice(user, 1)
              this.loadDirectory(this.requestParameters)
            })
            .catch((response) => {
              this.$message.error('删除失败!')
            })
        })
        .catch(() => {
          this.$message.info('已取消操作!')
        })
    },
    // 8.确认修改的目录
    async editconfirm () {
      this.isLoading = true // 加载
      this.formData.id = this.editId
      try {
        await update(this.formData)
        this.$message.success('修改成功')
        this.editDialogVisible = false
        this.isLoading = false // 请求结束
        this.loadDirectory()
        this.formData.subjectID = ''
        this.formData.directoryName = ''
        this.$refs.dataForm.clearValidate()
      } catch (err) {
        console.log(err)
      }
    },
    // 7.修改的弹出框
    async hEditRev (id) {
      this.editId = id
      this.editDialogVisible = true
      this.loadSubject()
      try {
        const res = await detail({ id })
        console.log(res)
        this.formData.subjectID = res.data.subjectID
        this.formData.directoryName = res.data.directoryName
      } catch (err) {
        console.log(err)
      }
    },
    // 6.添加数据目录
    confirm () {
      this.$refs.dataForm.validate(async (valid) => {
        if (valid) {
          this.isLoading = true // 加载
          try {
            console.log(await add(this.formData))
            await add(this.formData)
            this.$message.success('添加成功')
            this.centerDialogVisible = false
            this.isLoading = true // 结束加载
            this.loadDirectory()
            this.formData.subjectID = ''
            this.formData.directoryName = ''
            this.$refs.dataForm.clearValidate()
          } catch (error) {
            console.log(error)
            this.$message.error('添加失败')
            this.$refs.dataForm.clearValidate()
          }
        } else {
          return false
        }
      })
    },
    // 5.获取 添加数据 下拉选项 的 数据
    hAddDirectory () {
      this.centerDialogVisible = true
      this.loadSubject()
    },
    async loadSubject () {
      const res = await simple()
      this.subjectList = res.data
    },
    // 11.取消弹出框
    hCancel () {
      // 添加的弹出框
      this.centerDialogVisible = false
      this.$refs.dataForm.clearValidate()
      // 清空弹出框里的输入框
      this.formData.subjectID = null
      this.formData.directoryName = ''
      // 修改的弹出框
      this.editDialogVisible = false
    },
    // 4.搜索输入框
    searchInput () {
      this.loadDirectory()
    },
    // 3.获取表单数据
    async loadDirectory () {
      this.isLoading = true
      const res = await list(this.requestParameters)
      console.log(res)
      // 1.1 获取数据
      this.directoryList = res.data.items
      // 1.2 获取总条数
      this.total = res.data.counts
      // 1.3 灰色消息提示
      this.alertText = `共 ${this.total} 条记录`
      // 1.4 不加载
      this.isLoading = false
    },
    // 通过学科分类 跳转 获取 数据
    async loadSubjectQuery (id) {
      this.isLoading = true
      this.requestParameters.subjectID = Number(id)
      this.formData.subjectID = Number(id)
      const res = await list(this.requestParameters)
      console.log(res)
      // 1.1 获取数据
      this.directoryList = res.data.items
      // 1.2 获取总条数
      this.total = res.data.counts
      // 1.3 灰色消息提示
      this.alertText = `共 ${this.total} 条记录`
      // 1.4 不加载
      this.isLoading = false
    },
    // 2.分页
    // 进入某一页
    handleSizeChange (val) {
      this.clearInput()
      this.requestParameters.pagesize = val
      if (this.requestParameters.page === 1) {
        this.loadDirectory(this.requestParameters)
      }
    },
    // 每页显示信息条数
    handleCurrentChange (val) {
      this.clearInput()
      this.requestParameters.page = val
      this.loadDirectory()
    },
    // 1.清除搜索框
    clearInput () {
      this.requestParameters.directoryName = null
      this.requestParameters.state = null
      this.loadDirectory()
    }
  },
  created () {
    if (!this.$route.query.id || !this.$route.query.name) {
      this.loadDirectory()
    } else {
      // this.cardName = unescape(this.$route.query.name) // 转#
      this.cardName = this.$route.query.name
      this.loadSubjectQuery(this.$route.query.id)
    }
  },
  // 监听 : 学科跳转 目录 目录刷新清空
  watch: {
    $route (newVal, oldVal) {
      this.formData.subjectID = null
      this.formData.directoryName = ''
      this.requestParameters.subjectID = null
      this.loadDirectory()
    }
  }
}
</script>
<style scoped lang='css'>
.directorys-container {
  margin: 10px;
}
/* input 宽高 */
div /deep/.el-input--medium .el-input__inner {
  height: 32px;
  line-height: 32px;
}
/* 页码位置 */
.el-pagination /deep/ .el-pagination__jump {
  margin-left: 0px;
}
/* 表格数据居中 */
.el-table /deep/ .cell {
  text-align: center;
}
el-card /deep/ el-card-header{
    padding: 18px 20px;
    border-bottom: 1px solid #ebeef5;
    box-sizing: border-box;
}
</style>
