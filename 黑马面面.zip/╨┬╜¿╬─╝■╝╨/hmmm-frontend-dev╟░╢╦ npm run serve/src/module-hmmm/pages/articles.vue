<template>
  <div class='container'>
    <el-card class="box-card">
  <div  class="clearfix">
    <el-form ref="form" :model="form" label-width="80px" size="small">
<el-col :span="5">
 <el-form-item label="关键字" >
      <el-input v-model="form.keyword" placeholder="根据文章标题搜索" ></el-input>
  </el-form-item>
</el-col>
<el-col :span="15">
<el-form-item label="状态">
      <el-select v-model="form.state" placeholder="请选择">
      <el-option label="启用" value="1"></el-option>
      <el-option label="禁用" value="0"></el-option>
    </el-select>
     <el-button style="margin-left:8px;" size="small" @click="query">清除</el-button>
     <el-button type="primary" size="small" @click="searchData">搜索</el-button>
  </el-form-item>
</el-col>
  <el-col :span="4">
    <el-form-item>
     <el-button type="success" icon="el-icon-edit" style="float:right;" size="small" @click="addArticles('add')">新增技巧</el-button>
     </el-form-item>
  </el-col>
<el-col  >

</el-col>
  </el-form>
  </div>
  <el-alert
  :closable="false"
    :title="`数据一共${total_count}条`"
    type="info"
    show-icon>
  </el-alert>
  <!-- 表格 -->
 <el-table
      :data="tableData"
      style="width: 100%; margin-top: 16px">
      <el-table-column
        prop="id"
        label="序号"
        width="80">
      </el-table-column>
      <el-table-column
        prop="title"
        label="文章标题"
        width="420">
        <template slot-scope="scope">
          <span v-html="scope.row.title" style="margin-right: 5px;"></span>
          <i class="el-icon-film" v-if="scope.row.videoURL" @click="videoOpen(scope.row.videoURL)" style="color: #00f; font-size: 16px"></i>
        </template>
      </el-table-column>
      <el-table-column
        prop="visits"
        label="阅读数"
        width="150">
      </el-table-column>
      <el-table-column
        prop="username"
        label="录入人">
      </el-table-column>
      <el-table-column
        prop="createTime"
        label="录入时间">
         <template slot-scope="scope">
            <span>{{scope.row.createTime | fFormDate}}</span>
      </template>
      </el-table-column>
      <el-table-column
        label="状态"
        width="100">
        <template slot-scope="scope">
         <span v-if="scope.row.state" type="text">已启用</span>
         <span v-else type="text">已禁用</span>
        </template>
      </el-table-column>
      <el-table-column
        label="操作">
        <template slot-scope="scope">
          <el-button type="text" @click="previewArticle(scope.row)">预览</el-button>
          <el-button v-if="scope.row.state" type="text" @click="changeState(scope.row)">禁用</el-button>
          <el-button v-else type="text" @click="changeState(scope.row)">启用</el-button>
          <el-button  type="text" :disabled="!scope.row.state" @click="addArticles(scope.row)">修改</el-button>
          <el-button type="text" @click="deleteArticle(scope.row.id)" :disabled="!scope.row.state">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件 -->
     <div class="block">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="Number(curpage)"
      :page-sizes="[5, 10, 20, 30]"
      :page-size="Number(pagesize)"
      background
      style="margin:20px 0; float:right;"
      layout="prev, pager, next,sizes, jumper"
      :total="total_count">
    </el-pagination>
  </div>
  <!-- end -->
  <!-- 视频播放弹出层 -->
  <el-dialog :visible.sync="dialogFormVisible"  width="40%" @close="closeDialog" class="dialog" top="3vh">
    <video :src="videoURL" autoplay  class="video"
         width="100%"></video>
  </el-dialog>
  <!-- 新增标签弹层 -->
  <add v-model="formData"></add>
</el-card>
  </div>
</template>
<script>
import { list, remove, changeState } from '@/api/hmmm/articles'
import Add from './../pages/articlesAdd'
export default {
  name: 'articleAdd',
  components: {
    Add
  },
  data () {
    return {
      form: {
        keyword: '',
        state: ''
      },
      tableData: [],
      total_count: 0,
      curpage: 0,
      pagesize: 0,
      dialogFormVisible: false,
      videoURL: '',
      // 弹层数据
      formData: {
        pageTitle: '文章', // 页面标题
        text: '',
        dialogFormVisible: false,
        id: 0,
        videoURL: null,
        title: '',
        articleBody: '',
        username: '',
        createTime: '',
        state: 0
      }
    }
  },
  created () {
    this.interview()
  },
  // 监听数据
  watch: {
    'formData.dialogFormVisible' (newData, oldData) {
      if (!newData) {
        this.interview()
      }
    }
  },
  filters: {
    // 时间格式转换
    fFormDate (val) {
      const time = new Date(val)
      const y = time.getFullYear() < 10 ? '0' + time.getFullYear() : time.getFullYear()
      const m = (time.getMonth() + 1) < 10 ? '0' + (time.getMonth() + 1) : (time.getMonth() + 1)
      const d = time.getDate() < 10 ? '0' + time.getDate() : time.getDate()
      const h = time.getHours() < 10 ? '0' + time.getHours() : time.getHours()
      const mn = time.getMinutes() < 10 ? '0' + time.getMinutes() : time.getMinutes()
      const s = time.getSeconds() < 10 ? '0' + time.getSeconds() : time.getSeconds()
      return y + '-' + m + '-' + d + ' ' + h + ':' + mn + ':' + s
    }
  },
  methods: {
    // 清除视频地址
    closeDialog () {
      this.videoURL = ''
    },
    // 视频播放
    videoOpen (url) {
      this.dialogFormVisible = true
      this.videoURL = url
    },
    // 搜索数据
    async  searchData () {
      this.page = 1
      this.interview(this.form)
    },
    // 搜索框的数据清空
    query () {
      this.form = {}
    },
    // 改变数据状态
    changeState (row) {
      if (row.state === 1) {
        row.state = 0
      } else {
        row.state = 1
      }

      changeState({ id: row.id, state: row.state })
    },
    // 点击删除数据
    deleteArticle (id) {
      this.$confirm('此操作将永久删除该文章, 是否继续?', '提示', {
        type: 'warning'
      })
        .then(async () => {
          await remove({ id: id })
            .then(response => {
              this.$message.success('删除成功!')
              this.interview()
            })
            .catch(response => {
              this.$message.error('删除失败!')
            })
        })
        .catch(() => {
          this.$message.info('已取消操作!')
        })
    },
    // 发送请求,获取列表数据
    async interview (params) {
      // const res = await list({ page: this.curpage, pagesize: this.pagesize })
      const res = await list(params)
      this.tableData = res.data.items
      this.total_count = res.data.counts
      this.pagesize = res.data.pagesize
      this.curpage = res.data.page
    },
    // 接收当前在第几页
    handleCurrentChange (page) {
      this.curpage = page
      this.interview({ page: this.curpage, pagesize: this.pagesize })
    },
    // 预览文章
    previewArticle (row) {
      this.formData.text = '预览'
      this.formData.articleBody = row.articleBody
      this.formData.title = row.title
      this.formData.dialogFormVisible = true
      this.formData.state = row.state
      this.formData.username = row.username
      this.formData.createTime = row.createTime
    },
    // 添加修改文章
    addArticles (row) {
      this.formData.id = row.id
      this.formData.videoURL = row.videoURL
      this.formData.title = row.title
      this.formData.articleBody = row.articleBody
      this.formData.dialogFormVisible = true
      if (row === 'add') {
        this.formData.text = '新增' // 给弹层传参
      } else {
        this.formData.text = '修改'
      }
    },
    // 每页显示信息条数
    handleSizeChange (pagesize) {
      this.pagesize = pagesize
      this.curpage = 1
      this.interview({ page: this.curpage, pagesize: this.pagesize })
    }
  }
}

</script>

<style scoped lang='css'>
.container {
  margin: 10px;
}
  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }
  .clearfix:after {
    clear: both
  }
.dialog /deep/ .el-dialog__close {
   width: 50px;
    height: 50px;
    position: fixed;
    top: 30px;
    left: 50%;
    transform: translate(-50%);
    background: rgba(0,0,0,.4);
    box-shadow: 0 0 5px rgba(0,0,0,.4);
    border-radius: 50%;
    text-align: center;
    line-height: 50px;
    color: #fff;
    font-size: 20px;
}
.dialog  /deep/ .el-dialog__header {
    padding: 0;
  }
.dialog  /deep/ .el-dialog__body {
  position: absolute;
  margin-top: 9999px;
  margin-top: 240px;
    padding: 0;
    background-color: transparent;
  }
  .dialog  /deep/ .el-dialog__body video {
    vertical-align: bottom;
  }
  .box-card {
    width: 100%;
  }
</style>
