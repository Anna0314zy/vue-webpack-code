<template>
  <div class="subjects-container">
    <el-card>
      <!-- ================== 1. 表头 ================== -->
      <!-- 学科名称 -->
      <el-row>
        <el-col :span="18">
          <el-form label-width="80px">
            <el-form-item label="学科名称" prop="subjectName">
              <el-input style="width: 200px" v-model="requestParameters.subjectName"> </el-input>
              <el-button size="small" style="margin-left: 10px" @click="clearInput">清除</el-button>
              <el-button type="primary" size="small" @click="searchInput">搜索</el-button>
            </el-form-item>
          </el-form>
        </el-col>
        <!-- 新增学科按钮 -->
        <el-col :span="6">
          <el-button
            class="filter-item fr"
            size="small"
            style="margin-left: 10px"
            type="success"
            icon="el-icon-edit"
            @click="addDialogVisible = true"
            >新增学科</el-button
          >
        </el-col>
      </el-row>

      <!-- 灰色消息提示 -->
      <el-alert
        v-if="alertText !== ''"
        :title="alertText"
        show-icon
        :closable="false"
        type="info"
        style="margin-bottom: 15px"
      >
      </el-alert>
      <!--================== 2. 表格 ==================-->
      <el-table :data="subjectsList" style="width: 100%" v-loading="isLoading">
        <el-table-column align="center" label="序号">
          <template slot-scope="scope">
            <span>{{(requestParameters.page - 1 ) * requestParameters.pagesize + ( scope.$index + 1 ) }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="学科名称">
          <template slot-scope="scope">
            <span>{{ scope.row.subjectName }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="创建者">
          <template slot-scope="scope">
            <span>{{ scope.row.username }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="创建日期">
          <template slot-scope="scope">
            <span>{{ scope.row.addDate }}</span>
          </template>
        </el-table-column>

        <el-table-column label="前台是否显示">
          <template slot-scope="scope">
            <span v-if="scope.row.isFrontDisplay===0">否</span>
            <span v-else-if="scope.row.isFrontDisplay===1">是</span>

          </template>
        </el-table-column>

        <el-table-column align="center" label="二级目录">
          <template slot-scope="scope">
            <span>{{ scope.row.twoLevelDirectory }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="标签">
          <template slot-scope="scope">
            <span>{{ scope.row.tags }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="题目数量">
          <template slot-scope="scope">
            <span>{{ scope.row.totals }}</span>
          </template>
        </el-table-column>

        <!-- 操作按钮 -->
        <el-table-column
          align="center"
          label="操作"
          width="280"
          class-name="small-padding fixed-width"
        >
          <!-- slot-scope="scope" -->
          <template slot-scope="scope">
            <el-button
              type="text"
              @click="hEditSubjects(scope.row)"
              >学科分类</el-button
            >
            <el-button type="text" @click="hEditTags(scope.$index, scope.row)"
              >学科标签</el-button
            >
            <el-button
              type="text"
              class="filter-item"
              @click="hEditRev(scope.row.id)"
              >修改</el-button
            >
            <el-button type="text" @click="hEditDel(scope.row.id)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <!-- end -->
      <!-- 分页 -->
      <div class="pagination" style="margin-top: 20px; text-align: right">
        <div class="pages">
          <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="Number(requestParameters.page)"
            :total="Number(total)"
            :page-size="Number(requestParameters.pagesize)"
            :page-sizes="[10, 20, 30, 50]"
            layout=" prev, pager, next,sizes, jumper"
            :disabled="isLoading"
          ></el-pagination>
        </div>
      </div>
      <!-- 添加 弹框 -->
      <el-dialog
        :visible.sync="addDialogVisible"
        title="学科"
        width="400px"
        :destroy-on-close="true"
        center
      >
        <el-form
          label-width="80px"
          :rules="ruleInline"
          ref="dataForm"
          :model="formData"
        >
          <el-form-item label="学科名称" prop="subjectName">
            <el-input
              placeholder="请输入学科名称"
              v-model="formData.subjectName"
            ></el-input>
          </el-form-item>

          <el-form-item label="是否显示">
            <el-switch
              v-model="formData.isFrontDisplay"
              active-color="#13ce66"
              inactive-color="#ff4949"
            >
            </el-switch>
          </el-form-item>
          <el-form-item>
            <span class="dialog-footer">
              <el-button @click="hCancel">取消</el-button>
              <el-button type="primary" @click="confirm" :loading="isLoading">确认</el-button>
            </span>
          </el-form-item>
        </el-form>
      </el-dialog>
      <!-- 修改 弹框 -->
            <el-dialog
                  :visible.sync="editDialogVisible"
                  title="学科"
                  width="400px"
                  :destroy-on-close="true"
                  center>
               <el-form label-width="80px"
                        :rules="ruleInline"
                         ref="dataForm"
                         :model="formData">
              <el-form-item label="学科名称" prop="subjectName">
                  <el-input placeholder="请输入学科名称"
                  v-model="formData.subjectName"
                  ></el-input>
               </el-form-item>

                <el-form-item label="是否显示">
                   <el-switch v-model="formData.isFrontDisplay"
                   active-color="#13ce66"
                   inactive-color="#ff4949">
                   </el-switch>
                </el-form-item>
               <el-form-item>
                 <span class="dialog-footer">
                  <el-button  @click="hCancel">取消</el-button>
                  <el-button type="primary" @click="editconfirm" :loading="isLoading">确认</el-button>
               </span>
               </el-form-item>
               </el-form>
            </el-dialog>
    </el-card>
  </div>
</template>

<script>
import { list, remove, add, detail, update } from '@/api/hmmm/subjects'
export default {
  name: 'subjects',
  data () {
    return {
      isLoading: false, // 加载
      editDialogVisible: false, // 修改
      addDialogVisible: false, // 添加
      value: true, // 是否显示开关
      subjectsList: [], // 表单数据
      total: null, // 页数
      alertText: '', // 灰色消息提示
      editId: null, // 修改需要的Id
      requestParameters: {
        subjectName: null, // 搜索关键字
        // 请求页数
        page: 1,
        pagesize: 10
      },
      formData: {
        subjectName: '', // 学科名称
        isFrontDisplay: true // 是否显示
      },
      ruleInline: {
        subjectName: [
          { required: true, message: '请输入学科名称', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    // 9.搜索输入框
    searchInput () {
      this.loadSubjects()
    },
    // 8.清除搜索框
    clearInput () {
      this.requestParameters.subjectName = null
      this.loadSubjects()
    },
    // 7.添加数据
    confirm () {
      this.$refs.dataForm.validate(async (valid) => {
        if (valid) {
          this.isLoading = true // 加载
          try {
            await add(this.formData)
            this.$message.success('添加成功')
            this.addDialogVisible = false
            this.isLoading = false // 加载结束
            this.loadSubjects()
            this.formData.subjectName = ''
            this.formData.isFrontDisplay = true
            this.$refs.dataForm.clearValidate()
          } catch (error) {
            console.log(error)
            this.$message.error('添加失败')
            this.$refs.dataForm.clearValidate()
          }
        } else {
          return false
        }
      })
    },
    // 取消
    hCancel () {
      this.addDialogVisible = false
      this.$refs.dataForm.clearValidate()
      this.formData.subjectName = ''
      this.formData.isFrontDisplay = true
      this.editDialogVisible = false
    },
    // 7.删除数据
    hEditDel (user) {
      this.$confirm('此操作将永久删除用户 ' + ', 是否继续?', '提示', {
        type: 'warning'
      })
        .then(async () => {
          await remove({ id: user })
            .then((response) => {
              this.$message.success('成功删除了用户 ' + '!')
              this.subjectsList.splice(user, 1)
              this.loadSubjects(this.requestParameters)
            })
            .catch((response) => {
              this.$message.error('删除失败!')
            })
        })
        .catch(() => {
          this.$message.info('已取消操作!')
        })
    },
    // 6.确认修改数据
    async editconfirm () {
      this.formData.id = this.editId
      this.isLoading = true // 加载
      try {
        await update(this.formData)
        this.$message.success('修改成功')
        this.editDialogVisible = false
        this.isLoading = false // 加载结束
        this.loadSubjects()
        this.formData.subjectName = ''
        this.formData.isFrontDisplay = true
        this.$refs.dataForm.clearValidate()
      } catch (err) {
        console.log(err)
      }
    },
    // 5.弹出修改
    async hEditRev (id) {
      this.editId = id
      try {
        const res = await detail({ id })
        // console.log(res)
        this.formData.subjectName = res.data.subjectName
        this.formData.isFrontDisplay = !!res.data.isFrontDisplay
        this.editDialogVisible = true
      } catch (err) {
        console.log(err)
      }
    },
    // 3. 用户点击了学科分类 进行路由跳转
    hEditSubjects (row) {
      // 路由跳转
      this.$router.push(`/subjects/directorys?id=${row.id}&name=${encodeURIComponent(row.subjectName)}`)
    },
    // 4. 用户点击了学科标签 进行路由跳转
    hEditTags (index, row) {
      // 路由跳转
      this.$router.push(`/subjects/tags?id=${row.id}&name=${encodeURIComponent(row.subjectName)}`)
    },
    // 1. 获取表格数据
    async loadSubjects () {
      this.isLoading = true
      const { data: res } = await list(this.requestParameters)
      // 1.1 获取数据给subjectsList
      this.subjectsList = res.items
      // 1.2 获取总条数
      this.total = res.counts
      // 1.3 灰色消息提示
      this.alertText = `共 ${this.total} 条记录`
      // 1.4 不加载
      this.isLoading = false
    },
    // 2.分页
    // 进入某一页
    handleSizeChange (val) {
      this.requestParameters.pagesize = val
      if (this.requestParameters.page === 1) {
        this.loadSubjects(this.requestParameters)
      }
    },
    // 每页显示信息条数
    handleCurrentChange (val) {
      this.clearInput()
      this.requestParameters.page = val
      this.loadSubjects()
    }
  },
  created () {
    this.loadSubjects()
  }
}
</script>

<style scoped lang='css'>
.subjects-container {
  margin: 10px;
}
/* input 宽高 */
div /deep/.el-input--medium .el-input__inner {
  height: 32px;
  line-height: 32px;
}
/* 页码位置 */
.el-pagination /deep/ .el-pagination__jump {
  margin-left: 0px;
}
/* 表格数据居中 */
.el-table /deep/ .cell {
  text-align: center;
}
</style>
